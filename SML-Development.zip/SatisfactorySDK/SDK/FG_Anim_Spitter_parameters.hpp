#pragma once

// Satisfactory SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "FG_Anim_Spitter_classes.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Anim_Spitter.Anim_Spitter_C.CalculateAnimGraphVariables
struct UAnim_Spitter_C_CalculateAnimGraphVariables_Params
{
};

// Function Anim_Spitter.Anim_Spitter_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_Spitter_AnimGraphNode_TransitionResult_C9A2C4744CC31A8CA3DA6398B7FABFD2
struct UAnim_Spitter_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_Spitter_AnimGraphNode_TransitionResult_C9A2C4744CC31A8CA3DA6398B7FABFD2_Params
{
};

// Function Anim_Spitter.Anim_Spitter_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_Spitter_AnimGraphNode_TransitionResult_F59AB4D046321D1D1D4ED6BFFA4CE266
struct UAnim_Spitter_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_Spitter_AnimGraphNode_TransitionResult_F59AB4D046321D1D1D4ED6BFFA4CE266_Params
{
};

// Function Anim_Spitter.Anim_Spitter_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_Spitter_AnimGraphNode_TransitionResult_E5A14AC943454B0D928B91923D852F46
struct UAnim_Spitter_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_Spitter_AnimGraphNode_TransitionResult_E5A14AC943454B0D928B91923D852F46_Params
{
};

// Function Anim_Spitter.Anim_Spitter_C.AnimNotify_SpitterWalkToRunNotify
struct UAnim_Spitter_C_AnimNotify_SpitterWalkToRunNotify_Params
{
};

// Function Anim_Spitter.Anim_Spitter_C.OnRadialDamageTaken
struct UAnim_Spitter_C_OnRadialDamageTaken_Params
{
};

// Function Anim_Spitter.Anim_Spitter_C.OnPointDamageTaken
struct UAnim_Spitter_C_OnPointDamageTaken_Params
{
	struct FVector*                                    shootDIrection;                                           // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Anim_Spitter.Anim_Spitter_C.BlueprintUpdateAnimation
struct UAnim_Spitter_C_BlueprintUpdateAnimation_Params
{
	float*                                             DeltaTimeX;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Anim_Spitter.Anim_Spitter_C.ExecuteUbergraph_Anim_Spitter
struct UAnim_Spitter_C_ExecuteUbergraph_Anim_Spitter_Params
{
	int                                                EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
