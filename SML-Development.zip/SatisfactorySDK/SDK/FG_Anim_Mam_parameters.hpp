#pragma once

// Satisfactory SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "FG_Anim_Mam_classes.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Anim_Mam.Anim_Mam_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_Mam_AnimGraphNode_TransitionResult_7B42FA4D4C5AE3B0E0A785B67992E8C9
struct UAnim_Mam_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_Mam_AnimGraphNode_TransitionResult_7B42FA4D4C5AE3B0E0A785B67992E8C9_Params
{
};

// Function Anim_Mam.Anim_Mam_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_Mam_AnimGraphNode_TransitionResult_8CA4CF194793432BEFBFA48EC6C1D6B4
struct UAnim_Mam_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_Mam_AnimGraphNode_TransitionResult_8CA4CF194793432BEFBFA48EC6C1D6B4_Params
{
};

// Function Anim_Mam.Anim_Mam_C.BlueprintUpdateAnimation
struct UAnim_Mam_C_BlueprintUpdateAnimation_Params
{
	float*                                             DeltaTimeX;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Anim_Mam.Anim_Mam_C.BlueprintInitializeAnimation
struct UAnim_Mam_C_BlueprintInitializeAnimation_Params
{
};

// Function Anim_Mam.Anim_Mam_C.HasPowerChanged
struct UAnim_Mam_C_HasPowerChanged_Params
{
	bool                                               State;                                                    // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Anim_Mam.Anim_Mam_C.AnimNotify_MamEnteredProducing
struct UAnim_Mam_C_AnimNotify_MamEnteredProducing_Params
{
};

// Function Anim_Mam.Anim_Mam_C.AnimNotify_MamLeftProducing
struct UAnim_Mam_C_AnimNotify_MamLeftProducing_Params
{
};

// Function Anim_Mam.Anim_Mam_C.BlueprintBeginPlay
struct UAnim_Mam_C_BlueprintBeginPlay_Params
{
};

// Function Anim_Mam.Anim_Mam_C.ExecuteUbergraph_Anim_Mam
struct UAnim_Mam_C_ExecuteUbergraph_Anim_Mam_Params
{
	int                                                EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
