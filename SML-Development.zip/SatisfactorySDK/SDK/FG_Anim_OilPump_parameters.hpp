#pragma once

// Satisfactory SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "FG_Anim_OilPump_classes.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Anim_OilPump.Anim_OilPump_C.AnimNotify_BurnerFlareNotify
struct UAnim_OilPump_C_AnimNotify_BurnerFlareNotify_Params
{
};

// Function Anim_OilPump.Anim_OilPump_C.AnimNotify_OilpumpEnteredProducingState
struct UAnim_OilPump_C_AnimNotify_OilpumpEnteredProducingState_Params
{
};

// Function Anim_OilPump.Anim_OilPump_C.AnimNotify_OilpumpLeftProducingState
struct UAnim_OilPump_C_AnimNotify_OilpumpLeftProducingState_Params
{
};

// Function Anim_OilPump.Anim_OilPump_C.AnimNotify_OilpumpEnteredOfflineState
struct UAnim_OilPump_C_AnimNotify_OilpumpEnteredOfflineState_Params
{
};

// Function Anim_OilPump.Anim_OilPump_C.AnimNotify_OilpumpLeftOfflineState
struct UAnim_OilPump_C_AnimNotify_OilpumpLeftOfflineState_Params
{
};

// Function Anim_OilPump.Anim_OilPump_C.ExecuteUbergraph_Anim_OilPump
struct UAnim_OilPump_C_ExecuteUbergraph_Anim_OilPump_Params
{
	int                                                EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
