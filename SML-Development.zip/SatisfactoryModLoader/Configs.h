#pragma once
#include <Lib.h>

namespace SML {
	extern bool loadConsole;
	SML_API extern bool debugOutput;
	extern bool supressErrors;
	extern bool chatCommands;
	extern bool crashReporter;
	extern bool unsafeMode;
}