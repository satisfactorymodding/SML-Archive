// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently

//TODO: fix this so it knows that windows exists
//#include <detours.h>
//#include <../SatisfactorySDK/SDK.hpp>
//#include <Lib.h>

#pragma once
