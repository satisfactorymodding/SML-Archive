#include <stdafx.h>
#include "Configs.h"

namespace SML {
	bool loadConsole = true;
	bool debugOutput = false;
	bool supressErrors = false;
	bool chatCommands = true;
	bool crashReporter = true;
	bool unsafeMode = false;
}