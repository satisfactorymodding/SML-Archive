#include <stdafx.h>
#define HOOKLOADER_EXPORTS

#include <game/Player.h>
#include <game/Input.h>
#include <game/Utility.h>
#include <game/Global.h>
#include <game/UI.h>
#include <game/Etc.h>
#include <util/FKey.h>
#include <game/SDKHooks.h>