#pragma once

// Satisfactory SDK (V0.1.6 - CL#98445)

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "SF_Anim_OilRefinery_classes.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Anim_OilRefinery.Anim_OilRefinery_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_OilRefinery_AnimGraphNode_TransitionResult_771BDC794315C97B9114B58B67D53B9B
struct UAnim_OilRefinery_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_OilRefinery_AnimGraphNode_TransitionResult_771BDC794315C97B9114B58B67D53B9B_Params
{
};

// Function Anim_OilRefinery.Anim_OilRefinery_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_OilRefinery_AnimGraphNode_TransitionResult_915C10B24BBBA51A6DF22CA3D0A78740
struct UAnim_OilRefinery_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_OilRefinery_AnimGraphNode_TransitionResult_915C10B24BBBA51A6DF22CA3D0A78740_Params
{
};

// Function Anim_OilRefinery.Anim_OilRefinery_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_OilRefinery_AnimGraphNode_SequencePlayer_F1EFB75748441598AB354FA6C373C89A
struct UAnim_OilRefinery_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_OilRefinery_AnimGraphNode_SequencePlayer_F1EFB75748441598AB354FA6C373C89A_Params
{
};

// Function Anim_OilRefinery.Anim_OilRefinery_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_OilRefinery_AnimGraphNode_TransitionResult_ADC926934470782C4CC4E4AA0FAF9BD1
struct UAnim_OilRefinery_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_OilRefinery_AnimGraphNode_TransitionResult_ADC926934470782C4CC4E4AA0FAF9BD1_Params
{
};

// Function Anim_OilRefinery.Anim_OilRefinery_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_OilRefinery_AnimGraphNode_SequencePlayer_13C879DC4AE2357A23B328B1442B4914
struct UAnim_OilRefinery_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_OilRefinery_AnimGraphNode_SequencePlayer_13C879DC4AE2357A23B328B1442B4914_Params
{
};

// Function Anim_OilRefinery.Anim_OilRefinery_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_OilRefinery_AnimGraphNode_SequencePlayer_049CFCF849B615B553EE89B9F2D39FC7
struct UAnim_OilRefinery_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_OilRefinery_AnimGraphNode_SequencePlayer_049CFCF849B615B553EE89B9F2D39FC7_Params
{
};

// Function Anim_OilRefinery.Anim_OilRefinery_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_OilRefinery_AnimGraphNode_TransitionResult_00E703984606D1BEF63D9A807E113CCD
struct UAnim_OilRefinery_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_OilRefinery_AnimGraphNode_TransitionResult_00E703984606D1BEF63D9A807E113CCD_Params
{
};

// Function Anim_OilRefinery.Anim_OilRefinery_C.AnimNotify_OilRefineryEnteredOffline
struct UAnim_OilRefinery_C_AnimNotify_OilRefineryEnteredOffline_Params
{
};

// Function Anim_OilRefinery.Anim_OilRefinery_C.AnimNotify_OilRefineryEnteredProducing
struct UAnim_OilRefinery_C_AnimNotify_OilRefineryEnteredProducing_Params
{
};

// Function Anim_OilRefinery.Anim_OilRefinery_C.AnimNotify_OilRefineryLeftOffline
struct UAnim_OilRefinery_C_AnimNotify_OilRefineryLeftOffline_Params
{
};

// Function Anim_OilRefinery.Anim_OilRefinery_C.AnimNotify_OilRefineryLeftProducing
struct UAnim_OilRefinery_C_AnimNotify_OilRefineryLeftProducing_Params
{
};

// Function Anim_OilRefinery.Anim_OilRefinery_C.ExecuteUbergraph_Anim_OilRefinery
struct UAnim_OilRefinery_C_ExecuteUbergraph_Anim_OilRefinery_Params
{
	int                                                EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
