#pragma once

// Satisfactory SDK (V0.1.6 - CL#98445)

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "SF_Anim_GeneratorFuel_classes.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Anim_GeneratorFuel.Anim_GeneratorFuel_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_GeneratorFuel_AnimGraphNode_TransitionResult_CB02B87E41305029B6C4529024011E0D
struct UAnim_GeneratorFuel_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_GeneratorFuel_AnimGraphNode_TransitionResult_CB02B87E41305029B6C4529024011E0D_Params
{
};

// Function Anim_GeneratorFuel.Anim_GeneratorFuel_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_GeneratorFuel_AnimGraphNode_TransitionResult_F4B3DD684A170E4A4EE4A089E52E7C30
struct UAnim_GeneratorFuel_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_GeneratorFuel_AnimGraphNode_TransitionResult_F4B3DD684A170E4A4EE4A089E52E7C30_Params
{
};

// Function Anim_GeneratorFuel.Anim_GeneratorFuel_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_GeneratorFuel_AnimGraphNode_SequencePlayer_10A4F85D4EB0F8DAD2904D987D832A56
struct UAnim_GeneratorFuel_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_GeneratorFuel_AnimGraphNode_SequencePlayer_10A4F85D4EB0F8DAD2904D987D832A56_Params
{
};

// Function Anim_GeneratorFuel.Anim_GeneratorFuel_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_GeneratorFuel_AnimGraphNode_TransitionResult_F97B320E45E0C9E565BA47BFFFC7484F
struct UAnim_GeneratorFuel_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_GeneratorFuel_AnimGraphNode_TransitionResult_F97B320E45E0C9E565BA47BFFFC7484F_Params
{
};

// Function Anim_GeneratorFuel.Anim_GeneratorFuel_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_GeneratorFuel_AnimGraphNode_SequencePlayer_EB2D152B46A297F5491322A150C6D863
struct UAnim_GeneratorFuel_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_GeneratorFuel_AnimGraphNode_SequencePlayer_EB2D152B46A297F5491322A150C6D863_Params
{
};

// Function Anim_GeneratorFuel.Anim_GeneratorFuel_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_GeneratorFuel_AnimGraphNode_SequencePlayer_ADDF8C414177EAB5E999C999C0891FC7
struct UAnim_GeneratorFuel_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_GeneratorFuel_AnimGraphNode_SequencePlayer_ADDF8C414177EAB5E999C999C0891FC7_Params
{
};

// Function Anim_GeneratorFuel.Anim_GeneratorFuel_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_GeneratorFuel_AnimGraphNode_TransitionResult_26125A344B9DED34195BDEB37E7D23E5
struct UAnim_GeneratorFuel_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_GeneratorFuel_AnimGraphNode_TransitionResult_26125A344B9DED34195BDEB37E7D23E5_Params
{
};

// Function Anim_GeneratorFuel.Anim_GeneratorFuel_C.AnimNotify_FuelGenEnteredProducingState
struct UAnim_GeneratorFuel_C_AnimNotify_FuelGenEnteredProducingState_Params
{
};

// Function Anim_GeneratorFuel.Anim_GeneratorFuel_C.AnimNotify_FuelGenLeftProducingState
struct UAnim_GeneratorFuel_C_AnimNotify_FuelGenLeftProducingState_Params
{
};

// Function Anim_GeneratorFuel.Anim_GeneratorFuel_C.ExecuteUbergraph_Anim_GeneratorFuel
struct UAnim_GeneratorFuel_C_ExecuteUbergraph_Anim_GeneratorFuel_Params
{
	int                                                EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
