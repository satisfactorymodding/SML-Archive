#pragma once

// Satisfactory SDK (V0.1.6 - CL#98445)

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "SF_Anim_OilPump_classes.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Anim_OilPump.Anim_OilPump_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_OilPump_AnimGraphNode_TransitionResult_78BA76784E582F7D667CAC8F22AD1BB8
struct UAnim_OilPump_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_OilPump_AnimGraphNode_TransitionResult_78BA76784E582F7D667CAC8F22AD1BB8_Params
{
};

// Function Anim_OilPump.Anim_OilPump_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_OilPump_AnimGraphNode_TransitionResult_92613B6C49E875FC2F817CA2C8B5527D
struct UAnim_OilPump_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_OilPump_AnimGraphNode_TransitionResult_92613B6C49E875FC2F817CA2C8B5527D_Params
{
};

// Function Anim_OilPump.Anim_OilPump_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_OilPump_AnimGraphNode_SequencePlayer_84238E4D40417405E0471B8943A4C67F
struct UAnim_OilPump_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_OilPump_AnimGraphNode_SequencePlayer_84238E4D40417405E0471B8943A4C67F_Params
{
};

// Function Anim_OilPump.Anim_OilPump_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_OilPump_AnimGraphNode_TransitionResult_43F0088642F0F7CF36FDF4852D24B9BE
struct UAnim_OilPump_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_OilPump_AnimGraphNode_TransitionResult_43F0088642F0F7CF36FDF4852D24B9BE_Params
{
};

// Function Anim_OilPump.Anim_OilPump_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_OilPump_AnimGraphNode_SequencePlayer_3638272D4A8FDBC4C03869B542A98FA0
struct UAnim_OilPump_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_OilPump_AnimGraphNode_SequencePlayer_3638272D4A8FDBC4C03869B542A98FA0_Params
{
};

// Function Anim_OilPump.Anim_OilPump_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_OilPump_AnimGraphNode_SequencePlayer_B1AA41E7409CA3CA198A27BB2CF76CC1
struct UAnim_OilPump_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_OilPump_AnimGraphNode_SequencePlayer_B1AA41E7409CA3CA198A27BB2CF76CC1_Params
{
};

// Function Anim_OilPump.Anim_OilPump_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_OilPump_AnimGraphNode_TransitionResult_2729557F406A49CCEAF030B9D88ADC02
struct UAnim_OilPump_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_OilPump_AnimGraphNode_TransitionResult_2729557F406A49CCEAF030B9D88ADC02_Params
{
};

// Function Anim_OilPump.Anim_OilPump_C.AnimNotify_BurnerFlareNotify
struct UAnim_OilPump_C_AnimNotify_BurnerFlareNotify_Params
{
};

// Function Anim_OilPump.Anim_OilPump_C.AnimNotify_OilpumpEnteredProducingState
struct UAnim_OilPump_C_AnimNotify_OilpumpEnteredProducingState_Params
{
};

// Function Anim_OilPump.Anim_OilPump_C.AnimNotify_OilpumpLeftProducingState
struct UAnim_OilPump_C_AnimNotify_OilpumpLeftProducingState_Params
{
};

// Function Anim_OilPump.Anim_OilPump_C.AnimNotify_OilpumpEnteredOfflineState
struct UAnim_OilPump_C_AnimNotify_OilpumpEnteredOfflineState_Params
{
};

// Function Anim_OilPump.Anim_OilPump_C.AnimNotify_OilpumpLeftOfflineState
struct UAnim_OilPump_C_AnimNotify_OilpumpLeftOfflineState_Params
{
};

// Function Anim_OilPump.Anim_OilPump_C.ExecuteUbergraph_Anim_OilPump
struct UAnim_OilPump_C_ExecuteUbergraph_Anim_OilPump_Params
{
	int                                                EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
