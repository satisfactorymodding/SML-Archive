#pragma once

// Satisfactory SDK (V0.1.6 - CL#98445)

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "SF_Anim_ManufacturerMk1_classes.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Anim_ManufacturerMk1.Anim_ManufacturerMk1_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_ManufacturerMk1_AnimGraphNode_TransitionResult_FA726F7444281E7281A8ECBC930CFD58
struct UAnim_ManufacturerMk1_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_ManufacturerMk1_AnimGraphNode_TransitionResult_FA726F7444281E7281A8ECBC930CFD58_Params
{
};

// Function Anim_ManufacturerMk1.Anim_ManufacturerMk1_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_ManufacturerMk1_AnimGraphNode_TransitionResult_5F6C2EB1457A8837BCEF2FB321C95FE7
struct UAnim_ManufacturerMk1_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_ManufacturerMk1_AnimGraphNode_TransitionResult_5F6C2EB1457A8837BCEF2FB321C95FE7_Params
{
};

// Function Anim_ManufacturerMk1.Anim_ManufacturerMk1_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_ManufacturerMk1_AnimGraphNode_TransitionResult_6792BB424B071CD96567C7AD7663E0B1
struct UAnim_ManufacturerMk1_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_ManufacturerMk1_AnimGraphNode_TransitionResult_6792BB424B071CD96567C7AD7663E0B1_Params
{
};

// Function Anim_ManufacturerMk1.Anim_ManufacturerMk1_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_ManufacturerMk1_AnimGraphNode_TransitionResult_457C1B174B16BE0CF73C23982F383B06
struct UAnim_ManufacturerMk1_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_ManufacturerMk1_AnimGraphNode_TransitionResult_457C1B174B16BE0CF73C23982F383B06_Params
{
};

// Function Anim_ManufacturerMk1.Anim_ManufacturerMk1_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_ManufacturerMk1_AnimGraphNode_SequencePlayer_1DD95CA145CE257DB557138EBF6CCD3C
struct UAnim_ManufacturerMk1_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_ManufacturerMk1_AnimGraphNode_SequencePlayer_1DD95CA145CE257DB557138EBF6CCD3C_Params
{
};

// Function Anim_ManufacturerMk1.Anim_ManufacturerMk1_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_ManufacturerMk1_AnimGraphNode_SequencePlayer_A6041BE0497DB1695E1092A3B6E7B225
struct UAnim_ManufacturerMk1_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_ManufacturerMk1_AnimGraphNode_SequencePlayer_A6041BE0497DB1695E1092A3B6E7B225_Params
{
};

// Function Anim_ManufacturerMk1.Anim_ManufacturerMk1_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_ManufacturerMk1_AnimGraphNode_SequencePlayer_CB944E444C6800E012C59F818598A7A8
struct UAnim_ManufacturerMk1_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_ManufacturerMk1_AnimGraphNode_SequencePlayer_CB944E444C6800E012C59F818598A7A8_Params
{
};

// Function Anim_ManufacturerMk1.Anim_ManufacturerMk1_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_ManufacturerMk1_AnimGraphNode_TransitionResult_1CEFF83543FDFC2AA7280490EC14ED04
struct UAnim_ManufacturerMk1_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_ManufacturerMk1_AnimGraphNode_TransitionResult_1CEFF83543FDFC2AA7280490EC14ED04_Params
{
};

// Function Anim_ManufacturerMk1.Anim_ManufacturerMk1_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_ManufacturerMk1_AnimGraphNode_TransitionResult_56A39FA24B70F097CAE83FB5EF656952
struct UAnim_ManufacturerMk1_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_ManufacturerMk1_AnimGraphNode_TransitionResult_56A39FA24B70F097CAE83FB5EF656952_Params
{
};

// Function Anim_ManufacturerMk1.Anim_ManufacturerMk1_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_ManufacturerMk1_AnimGraphNode_TransitionResult_F5FD74CF4665DC291CF9D7B1F5DE98AA
struct UAnim_ManufacturerMk1_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_ManufacturerMk1_AnimGraphNode_TransitionResult_F5FD74CF4665DC291CF9D7B1F5DE98AA_Params
{
};

// Function Anim_ManufacturerMk1.Anim_ManufacturerMk1_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_ManufacturerMk1_AnimGraphNode_TransitionResult_E6ABA23E42EA726002BC46939CEDDF17
struct UAnim_ManufacturerMk1_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_ManufacturerMk1_AnimGraphNode_TransitionResult_E6ABA23E42EA726002BC46939CEDDF17_Params
{
};

// Function Anim_ManufacturerMk1.Anim_ManufacturerMk1_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_ManufacturerMk1_AnimGraphNode_SequencePlayer_F8A2A869435ADC182CD538962103861E
struct UAnim_ManufacturerMk1_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_ManufacturerMk1_AnimGraphNode_SequencePlayer_F8A2A869435ADC182CD538962103861E_Params
{
};

// Function Anim_ManufacturerMk1.Anim_ManufacturerMk1_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_ManufacturerMk1_AnimGraphNode_SequencePlayer_83DFB309404CB2392D86348CF19E61EE
struct UAnim_ManufacturerMk1_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_ManufacturerMk1_AnimGraphNode_SequencePlayer_83DFB309404CB2392D86348CF19E61EE_Params
{
};

// Function Anim_ManufacturerMk1.Anim_ManufacturerMk1_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_ManufacturerMk1_AnimGraphNode_SequencePlayer_657CE7B54D77FAB01E30B78C7DE0D0A6
struct UAnim_ManufacturerMk1_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_ManufacturerMk1_AnimGraphNode_SequencePlayer_657CE7B54D77FAB01E30B78C7DE0D0A6_Params
{
};

// Function Anim_ManufacturerMk1.Anim_ManufacturerMk1_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_ManufacturerMk1_AnimGraphNode_BlendListByBool_9DB38B79476B3AEC15DC6DBE6B3EB570
struct UAnim_ManufacturerMk1_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_ManufacturerMk1_AnimGraphNode_BlendListByBool_9DB38B79476B3AEC15DC6DBE6B3EB570_Params
{
};

// Function Anim_ManufacturerMk1.Anim_ManufacturerMk1_C.BlueprintUpdateAnimation
struct UAnim_ManufacturerMk1_C_BlueprintUpdateAnimation_Params
{
	float*                                             DeltaTimeX;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Anim_ManufacturerMk1.Anim_ManufacturerMk1_C.BlueprintInitializeAnimation
struct UAnim_ManufacturerMk1_C_BlueprintInitializeAnimation_Params
{
};

// Function Anim_ManufacturerMk1.Anim_ManufacturerMk1_C.AnimNotify_ConstructorComplexEnteredProducing
struct UAnim_ManufacturerMk1_C_AnimNotify_ConstructorComplexEnteredProducing_Params
{
};

// Function Anim_ManufacturerMk1.Anim_ManufacturerMk1_C.AnimNotify_ConstructorComplexLeftProducing
struct UAnim_ManufacturerMk1_C_AnimNotify_ConstructorComplexLeftProducing_Params
{
};

// Function Anim_ManufacturerMk1.Anim_ManufacturerMk1_C.AnimNotify_ConstructorComplexLeftOffline
struct UAnim_ManufacturerMk1_C_AnimNotify_ConstructorComplexLeftOffline_Params
{
};

// Function Anim_ManufacturerMk1.Anim_ManufacturerMk1_C.AnimNotify_ConstructorAdvEnteredOffline
struct UAnim_ManufacturerMk1_C_AnimNotify_ConstructorAdvEnteredOffline_Params
{
};

// Function Anim_ManufacturerMk1.Anim_ManufacturerMk1_C.HasPowerChanged
struct UAnim_ManufacturerMk1_C_HasPowerChanged_Params
{
	bool                                               State;                                                    // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Anim_ManufacturerMk1.Anim_ManufacturerMk1_C.ExecuteUbergraph_Anim_ManufacturerMk1
struct UAnim_ManufacturerMk1_C_ExecuteUbergraph_Anim_ManufacturerMk1_Params
{
	int                                                EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
