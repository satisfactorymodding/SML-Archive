#pragma once

// Satisfactory SDK (V0.1.6 - CL#98445)

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "SF_Anim_MinerMk1_classes.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Anim_MinerMk1.Anim_MinerMk1_C.SetupReloadTimer
struct UAnim_MinerMk1_C_SetupReloadTimer_Params
{
};

// Function Anim_MinerMk1.Anim_MinerMk1_C.ReloadTimer
struct UAnim_MinerMk1_C_ReloadTimer_Params
{
};

// Function Anim_MinerMk1.Anim_MinerMk1_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_MinerMk1_AnimGraphNode_SequencePlayer_9367EEFD4B2726AD204A5A963FA1D0D4
struct UAnim_MinerMk1_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_MinerMk1_AnimGraphNode_SequencePlayer_9367EEFD4B2726AD204A5A963FA1D0D4_Params
{
};

// Function Anim_MinerMk1.Anim_MinerMk1_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_MinerMk1_AnimGraphNode_TransitionResult_08F66A774DC7927D384EF28807B056AE
struct UAnim_MinerMk1_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_MinerMk1_AnimGraphNode_TransitionResult_08F66A774DC7927D384EF28807B056AE_Params
{
};

// Function Anim_MinerMk1.Anim_MinerMk1_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_MinerMk1_AnimGraphNode_SequencePlayer_309C66EC448B62CC35C683BBFDF9B3CE
struct UAnim_MinerMk1_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_MinerMk1_AnimGraphNode_SequencePlayer_309C66EC448B62CC35C683BBFDF9B3CE_Params
{
};

// Function Anim_MinerMk1.Anim_MinerMk1_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_MinerMk1_AnimGraphNode_SequencePlayer_CD513362432B727911A9E8803FCAAC71
struct UAnim_MinerMk1_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_MinerMk1_AnimGraphNode_SequencePlayer_CD513362432B727911A9E8803FCAAC71_Params
{
};

// Function Anim_MinerMk1.Anim_MinerMk1_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_MinerMk1_AnimGraphNode_TransitionResult_28F3013B45B7F27F7C671C9902192B2B
struct UAnim_MinerMk1_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_MinerMk1_AnimGraphNode_TransitionResult_28F3013B45B7F27F7C671C9902192B2B_Params
{
};

// Function Anim_MinerMk1.Anim_MinerMk1_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_MinerMk1_AnimGraphNode_TransitionResult_5586953F4FAB4C7B19E400885A50B47F
struct UAnim_MinerMk1_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_MinerMk1_AnimGraphNode_TransitionResult_5586953F4FAB4C7B19E400885A50B47F_Params
{
};

// Function Anim_MinerMk1.Anim_MinerMk1_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_MinerMk1_AnimGraphNode_TransitionResult_7041A21846343F6F20B12B87F046FACE
struct UAnim_MinerMk1_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_MinerMk1_AnimGraphNode_TransitionResult_7041A21846343F6F20B12B87F046FACE_Params
{
};

// Function Anim_MinerMk1.Anim_MinerMk1_C.AnimNotify_MinerEnteredReloadState
struct UAnim_MinerMk1_C_AnimNotify_MinerEnteredReloadState_Params
{
};

// Function Anim_MinerMk1.Anim_MinerMk1_C.AnimNotify_StartDrillVFX
struct UAnim_MinerMk1_C_AnimNotify_StartDrillVFX_Params
{
};

// Function Anim_MinerMk1.Anim_MinerMk1_C.BlueprintInitializeAnimation
struct UAnim_MinerMk1_C_BlueprintInitializeAnimation_Params
{
};

// Function Anim_MinerMk1.Anim_MinerMk1_C.AnimNotify_OnResumeProducing
struct UAnim_MinerMk1_C_AnimNotify_OnResumeProducing_Params
{
};

// Function Anim_MinerMk1.Anim_MinerMk1_C.AnimNotify_OnStopProducing
struct UAnim_MinerMk1_C_AnimNotify_OnStopProducing_Params
{
};

// Function Anim_MinerMk1.Anim_MinerMk1_C.AnimNotify_StartEngineLoop
struct UAnim_MinerMk1_C_AnimNotify_StartEngineLoop_Params
{
};

// Function Anim_MinerMk1.Anim_MinerMk1_C.ExecuteUbergraph_Anim_MinerMk1
struct UAnim_MinerMk1_C_ExecuteUbergraph_Anim_MinerMk1_Params
{
	int                                                EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
