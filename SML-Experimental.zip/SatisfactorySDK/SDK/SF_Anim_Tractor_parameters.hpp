#pragma once

// Satisfactory SDK (V0.1.6 - CL#98445)

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "SF_Anim_Tractor_classes.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Anim_Tractor.Anim_Tractor_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_Tractor_AnimGraphNode_ModifyBone_EC1CAF97464D6DE81FC0748046B0E972
struct UAnim_Tractor_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_Tractor_AnimGraphNode_ModifyBone_EC1CAF97464D6DE81FC0748046B0E972_Params
{
};

// Function Anim_Tractor.Anim_Tractor_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_Tractor_AnimGraphNode_ModifyBone_099B4C1F49B2CD259B77A6ACDF48E461
struct UAnim_Tractor_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_Tractor_AnimGraphNode_ModifyBone_099B4C1F49B2CD259B77A6ACDF48E461_Params
{
};

// Function Anim_Tractor.Anim_Tractor_C.BlueprintUpdateAnimation
struct UAnim_Tractor_C_BlueprintUpdateAnimation_Params
{
	float*                                             DeltaTimeX;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Anim_Tractor.Anim_Tractor_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_Tractor_AnimGraphNode_ModifyBone_CADC6C414E31A4306180BFAF558AD876
struct UAnim_Tractor_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_Tractor_AnimGraphNode_ModifyBone_CADC6C414E31A4306180BFAF558AD876_Params
{
};

// Function Anim_Tractor.Anim_Tractor_C.ExecuteUbergraph_Anim_Tractor
struct UAnim_Tractor_C_ExecuteUbergraph_Anim_Tractor_Params
{
	int                                                EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
