#pragma once

// Satisfactory SDK (V0.1.6 - CL#98445)

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "SF_Anim_GeneratorGeoThermal_classes.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Anim_GeneratorGeoThermal.Anim_GeneratorGeoThermal_C.ExecuteUbergraph_Anim_GeneratorGeoThermal
struct UAnim_GeneratorGeoThermal_C_ExecuteUbergraph_Anim_GeneratorGeoThermal_Params
{
	int                                                EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
