#pragma once

// Satisfactory SDK (V0.1.6 - CL#98445)

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "SF_Anim_ResourceMiner_classes.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Anim_ResourceMiner.Anim_ResourceMiner_C.AnimNotify_MineComplete
struct UAnim_ResourceMiner_C_AnimNotify_MineComplete_Params
{
};

// Function Anim_ResourceMiner.Anim_ResourceMiner_C.AnimNotify_StopMining
struct UAnim_ResourceMiner_C_AnimNotify_StopMining_Params
{
};

// Function Anim_ResourceMiner.Anim_ResourceMiner_C.AnimNotify_MineVfx
struct UAnim_ResourceMiner_C_AnimNotify_MineVfx_Params
{
};

// Function Anim_ResourceMiner.Anim_ResourceMiner_C.AnimNotify_StartCameraShake
struct UAnim_ResourceMiner_C_AnimNotify_StartCameraShake_Params
{
};

// Function Anim_ResourceMiner.Anim_ResourceMiner_C.AnimNotify_PickRingSound
struct UAnim_ResourceMiner_C_AnimNotify_PickRingSound_Params
{
};

// Function Anim_ResourceMiner.Anim_ResourceMiner_C.AnimNotify_SecondMineVfx
struct UAnim_ResourceMiner_C_AnimNotify_SecondMineVfx_Params
{
};

// Function Anim_ResourceMiner.Anim_ResourceMiner_C.ExecuteUbergraph_Anim_ResourceMiner
struct UAnim_ResourceMiner_C_ExecuteUbergraph_Anim_ResourceMiner_Params
{
	int                                                EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
