#pragma once

// Satisfactory SDK (V0.1.6 - CL#98445)

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "SF_Anim_SmallSpitter_classes.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Anim_SmallSpitter.Anim_SmallSpitter_C.CalculateAnimGraphVariables
struct UAnim_SmallSpitter_C_CalculateAnimGraphVariables_Params
{
};

// Function Anim_SmallSpitter.Anim_SmallSpitter_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmallSpitter_AnimGraphNode_TransitionResult_7956550A454F68AFBD620CB012F1789E
struct UAnim_SmallSpitter_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmallSpitter_AnimGraphNode_TransitionResult_7956550A454F68AFBD620CB012F1789E_Params
{
};

// Function Anim_SmallSpitter.Anim_SmallSpitter_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmallSpitter_AnimGraphNode_TransitionResult_2D6A0382465D1833544263BFF3E1CE17
struct UAnim_SmallSpitter_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmallSpitter_AnimGraphNode_TransitionResult_2D6A0382465D1833544263BFF3E1CE17_Params
{
};

// Function Anim_SmallSpitter.Anim_SmallSpitter_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmallSpitter_AnimGraphNode_TransitionResult_6A3F0B6849BE362F69BD22ABE4D6C58D
struct UAnim_SmallSpitter_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmallSpitter_AnimGraphNode_TransitionResult_6A3F0B6849BE362F69BD22ABE4D6C58D_Params
{
};

// Function Anim_SmallSpitter.Anim_SmallSpitter_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmallSpitter_AnimGraphNode_TransitionResult_2608467948BAB45340990FA93BB228F8
struct UAnim_SmallSpitter_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmallSpitter_AnimGraphNode_TransitionResult_2608467948BAB45340990FA93BB228F8_Params
{
};

// Function Anim_SmallSpitter.Anim_SmallSpitter_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmallSpitter_AnimGraphNode_TransitionResult_5CDF33754E0B7EF9F092F6A11FD769A5
struct UAnim_SmallSpitter_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmallSpitter_AnimGraphNode_TransitionResult_5CDF33754E0B7EF9F092F6A11FD769A5_Params
{
};

// Function Anim_SmallSpitter.Anim_SmallSpitter_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmallSpitter_AnimGraphNode_TransitionResult_7B4051C84348CD3B2162598F15E1A625
struct UAnim_SmallSpitter_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmallSpitter_AnimGraphNode_TransitionResult_7B4051C84348CD3B2162598F15E1A625_Params
{
};

// Function Anim_SmallSpitter.Anim_SmallSpitter_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmallSpitter_AnimGraphNode_BlendListByBool_8BD731A64DA189C14BC8A0B81F5A4DAB
struct UAnim_SmallSpitter_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmallSpitter_AnimGraphNode_BlendListByBool_8BD731A64DA189C14BC8A0B81F5A4DAB_Params
{
};

// Function Anim_SmallSpitter.Anim_SmallSpitter_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmallSpitter_AnimGraphNode_RotateRootBone_5189ACC84ECAE9DF7D4F5AB72F5E540E
struct UAnim_SmallSpitter_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmallSpitter_AnimGraphNode_RotateRootBone_5189ACC84ECAE9DF7D4F5AB72F5E540E_Params
{
};

// Function Anim_SmallSpitter.Anim_SmallSpitter_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmallSpitter_AnimGraphNode_RotateRootBone_9EC1C19848F03FE93FE4789003A59267
struct UAnim_SmallSpitter_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmallSpitter_AnimGraphNode_RotateRootBone_9EC1C19848F03FE93FE4789003A59267_Params
{
};

// Function Anim_SmallSpitter.Anim_SmallSpitter_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmallSpitter_AnimGraphNode_BlendListByBool_080580A645C23B7F45E24696998D3AA6
struct UAnim_SmallSpitter_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmallSpitter_AnimGraphNode_BlendListByBool_080580A645C23B7F45E24696998D3AA6_Params
{
};

// Function Anim_SmallSpitter.Anim_SmallSpitter_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmallSpitter_AnimGraphNode_RotationOffsetBlendSpace_78781CCC45DB4A32A0F2DB80621507BC
struct UAnim_SmallSpitter_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmallSpitter_AnimGraphNode_RotationOffsetBlendSpace_78781CCC45DB4A32A0F2DB80621507BC_Params
{
};

// Function Anim_SmallSpitter.Anim_SmallSpitter_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmallSpitter_AnimGraphNode_RotateRootBone_480463224ED0EE67C190E1990824BCBA
struct UAnim_SmallSpitter_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmallSpitter_AnimGraphNode_RotateRootBone_480463224ED0EE67C190E1990824BCBA_Params
{
};

// Function Anim_SmallSpitter.Anim_SmallSpitter_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmallSpitter_AnimGraphNode_ModifyBone_38B4181544FCC0E587C18491ADA53C1D
struct UAnim_SmallSpitter_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmallSpitter_AnimGraphNode_ModifyBone_38B4181544FCC0E587C18491ADA53C1D_Params
{
};

// Function Anim_SmallSpitter.Anim_SmallSpitter_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmallSpitter_AnimGraphNode_ModifyBone_ABB842644536808994F7659B96FABAC0
struct UAnim_SmallSpitter_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmallSpitter_AnimGraphNode_ModifyBone_ABB842644536808994F7659B96FABAC0_Params
{
};

// Function Anim_SmallSpitter.Anim_SmallSpitter_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmallSpitter_AnimGraphNode_ModifyBone_2BFCBFEF4439408F93800DB1AFAB7E01
struct UAnim_SmallSpitter_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmallSpitter_AnimGraphNode_ModifyBone_2BFCBFEF4439408F93800DB1AFAB7E01_Params
{
};

// Function Anim_SmallSpitter.Anim_SmallSpitter_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmallSpitter_AnimGraphNode_ModifyBone_C666E3B248702D330A6463B13D7E0618
struct UAnim_SmallSpitter_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmallSpitter_AnimGraphNode_ModifyBone_C666E3B248702D330A6463B13D7E0618_Params
{
};

// Function Anim_SmallSpitter.Anim_SmallSpitter_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmallSpitter_AnimGraphNode_ModifyBone_E50D36E14A5C4A2A305C6EA40BBFF82B
struct UAnim_SmallSpitter_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmallSpitter_AnimGraphNode_ModifyBone_E50D36E14A5C4A2A305C6EA40BBFF82B_Params
{
};

// Function Anim_SmallSpitter.Anim_SmallSpitter_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmallSpitter_AnimGraphNode_BlendListByBool_62C4980C47FA1D6E69614E879AC37536
struct UAnim_SmallSpitter_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmallSpitter_AnimGraphNode_BlendListByBool_62C4980C47FA1D6E69614E879AC37536_Params
{
};

// Function Anim_SmallSpitter.Anim_SmallSpitter_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmallSpitter_AnimGraphNode_BlendSpacePlayer_10D708C245333F512AF6239B1E973250
struct UAnim_SmallSpitter_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmallSpitter_AnimGraphNode_BlendSpacePlayer_10D708C245333F512AF6239B1E973250_Params
{
};

// Function Anim_SmallSpitter.Anim_SmallSpitter_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmallSpitter_AnimGraphNode_BlendListByBool_B77B6312406859C0F7DCBF985FF61B02
struct UAnim_SmallSpitter_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmallSpitter_AnimGraphNode_BlendListByBool_B77B6312406859C0F7DCBF985FF61B02_Params
{
};

// Function Anim_SmallSpitter.Anim_SmallSpitter_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmallSpitter_AnimGraphNode_TransitionResult_3F4F07424C54FE4B3F289DA48E9BE747
struct UAnim_SmallSpitter_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmallSpitter_AnimGraphNode_TransitionResult_3F4F07424C54FE4B3F289DA48E9BE747_Params
{
};

// Function Anim_SmallSpitter.Anim_SmallSpitter_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmallSpitter_AnimGraphNode_TransitionResult_109183044A7B4E46670A2D8C69D1789E
struct UAnim_SmallSpitter_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmallSpitter_AnimGraphNode_TransitionResult_109183044A7B4E46670A2D8C69D1789E_Params
{
};

// Function Anim_SmallSpitter.Anim_SmallSpitter_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmallSpitter_AnimGraphNode_TransitionResult_7615D6894F917658C7D85A8D21882C80
struct UAnim_SmallSpitter_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmallSpitter_AnimGraphNode_TransitionResult_7615D6894F917658C7D85A8D21882C80_Params
{
};

// Function Anim_SmallSpitter.Anim_SmallSpitter_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmallSpitter_AnimGraphNode_TransitionResult_B2AD22984B1F46D8AA99158597EA0A93
struct UAnim_SmallSpitter_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmallSpitter_AnimGraphNode_TransitionResult_B2AD22984B1F46D8AA99158597EA0A93_Params
{
};

// Function Anim_SmallSpitter.Anim_SmallSpitter_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmallSpitter_AnimGraphNode_TransitionResult_F6EE12A241242082CA63B59288B742EC
struct UAnim_SmallSpitter_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmallSpitter_AnimGraphNode_TransitionResult_F6EE12A241242082CA63B59288B742EC_Params
{
};

// Function Anim_SmallSpitter.Anim_SmallSpitter_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmallSpitter_AnimGraphNode_TransitionResult_F2BFD8E9417B922A4A6C66A2298D73EB
struct UAnim_SmallSpitter_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmallSpitter_AnimGraphNode_TransitionResult_F2BFD8E9417B922A4A6C66A2298D73EB_Params
{
};

// Function Anim_SmallSpitter.Anim_SmallSpitter_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmallSpitter_AnimGraphNode_TransitionResult_6F7C35D64C630E211DF61988112FB6A4
struct UAnim_SmallSpitter_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmallSpitter_AnimGraphNode_TransitionResult_6F7C35D64C630E211DF61988112FB6A4_Params
{
};

// Function Anim_SmallSpitter.Anim_SmallSpitter_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmallSpitter_AnimGraphNode_TransitionResult_03EBA1B14615160DFD1DFEBCC1D6D217
struct UAnim_SmallSpitter_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmallSpitter_AnimGraphNode_TransitionResult_03EBA1B14615160DFD1DFEBCC1D6D217_Params
{
};

// Function Anim_SmallSpitter.Anim_SmallSpitter_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmallSpitter_AnimGraphNode_TransitionResult_D8473D8145C7278FC5B1AFAD154D8CF0
struct UAnim_SmallSpitter_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmallSpitter_AnimGraphNode_TransitionResult_D8473D8145C7278FC5B1AFAD154D8CF0_Params
{
};

// Function Anim_SmallSpitter.Anim_SmallSpitter_C.AnimNotify_SpitterWalkToRunNotify
struct UAnim_SmallSpitter_C_AnimNotify_SpitterWalkToRunNotify_Params
{
};

// Function Anim_SmallSpitter.Anim_SmallSpitter_C.OnRadialDamageTaken
struct UAnim_SmallSpitter_C_OnRadialDamageTaken_Params
{
};

// Function Anim_SmallSpitter.Anim_SmallSpitter_C.OnPointDamageTaken
struct UAnim_SmallSpitter_C_OnPointDamageTaken_Params
{
	struct FVector*                                    shootDIrection;                                           // (BlueprintVisible, BlueprintReadOnly, Parm, IsPlainOldData)
};

// Function Anim_SmallSpitter.Anim_SmallSpitter_C.BlueprintUpdateAnimation
struct UAnim_SmallSpitter_C_BlueprintUpdateAnimation_Params
{
	float*                                             DeltaTimeX;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Anim_SmallSpitter.Anim_SmallSpitter_C.ExecuteUbergraph_Anim_SmallSpitter
struct UAnim_SmallSpitter_C_ExecuteUbergraph_Anim_SmallSpitter_Params
{
	int                                                EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
