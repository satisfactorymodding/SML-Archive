#pragma once

// Satisfactory SDK (V0.1.6 - CL#98445)

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "SF_Anim_3pRebargun_classes.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Anim_3pRebargun.Anim_3pRebargun_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_3pRebargun_AnimGraphNode_BlendListByBool_8D2ED78C40534FA16432CFA35EF25465
struct UAnim_3pRebargun_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_3pRebargun_AnimGraphNode_BlendListByBool_8D2ED78C40534FA16432CFA35EF25465_Params
{
};

// Function Anim_3pRebargun.Anim_3pRebargun_C.BlueprintUpdateAnimation
struct UAnim_3pRebargun_C_BlueprintUpdateAnimation_Params
{
	float*                                             DeltaTimeX;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Anim_3pRebargun.Anim_3pRebargun_C.AnimNotify_RebarGunIsLoaded3p
struct UAnim_3pRebargun_C_AnimNotify_RebarGunIsLoaded3p_Params
{
};

// Function Anim_3pRebargun.Anim_3pRebargun_C.AnimNotify_RebarGunIsNotLoaded3p
struct UAnim_3pRebargun_C_AnimNotify_RebarGunIsNotLoaded3p_Params
{
};

// Function Anim_3pRebargun.Anim_3pRebargun_C.ExecuteUbergraph_Anim_3pRebargun
struct UAnim_3pRebargun_C_ExecuteUbergraph_Anim_3pRebargun_Params
{
	int                                                EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
