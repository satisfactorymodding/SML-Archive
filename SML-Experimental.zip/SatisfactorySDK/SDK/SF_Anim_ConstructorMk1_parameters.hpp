#pragma once

// Satisfactory SDK (V0.1.6 - CL#98445)

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "SF_Anim_ConstructorMk1_classes.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Anim_ConstructorMk1.Anim_ConstructorMk1_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_ConstructorMk1_AnimGraphNode_TransitionResult_B4F6D3BF43B2690B477B0E907548A929
struct UAnim_ConstructorMk1_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_ConstructorMk1_AnimGraphNode_TransitionResult_B4F6D3BF43B2690B477B0E907548A929_Params
{
};

// Function Anim_ConstructorMk1.Anim_ConstructorMk1_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_ConstructorMk1_AnimGraphNode_TransitionResult_E6ABA23E42EA726002BC46939CEDDF17
struct UAnim_ConstructorMk1_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_ConstructorMk1_AnimGraphNode_TransitionResult_E6ABA23E42EA726002BC46939CEDDF17_Params
{
};

// Function Anim_ConstructorMk1.Anim_ConstructorMk1_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_ConstructorMk1_AnimGraphNode_SequenceEvaluator_E36F19304B3E29B2391B7BB7F3DA8B19
struct UAnim_ConstructorMk1_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_ConstructorMk1_AnimGraphNode_SequenceEvaluator_E36F19304B3E29B2391B7BB7F3DA8B19_Params
{
};

// Function Anim_ConstructorMk1.Anim_ConstructorMk1_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_ConstructorMk1_AnimGraphNode_TransitionResult_F5FD74CF4665DC291CF9D7B1F5DE98AA
struct UAnim_ConstructorMk1_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_ConstructorMk1_AnimGraphNode_TransitionResult_F5FD74CF4665DC291CF9D7B1F5DE98AA_Params
{
};

// Function Anim_ConstructorMk1.Anim_ConstructorMk1_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_ConstructorMk1_AnimGraphNode_SequencePlayer_3FAE7C4247011BD0A3130C8B850E7B46
struct UAnim_ConstructorMk1_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_ConstructorMk1_AnimGraphNode_SequencePlayer_3FAE7C4247011BD0A3130C8B850E7B46_Params
{
};

// Function Anim_ConstructorMk1.Anim_ConstructorMk1_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_ConstructorMk1_AnimGraphNode_SequencePlayer_278E0C114ADE9B04C6D7C091A85F7CD5
struct UAnim_ConstructorMk1_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_ConstructorMk1_AnimGraphNode_SequencePlayer_278E0C114ADE9B04C6D7C091A85F7CD5_Params
{
};

// Function Anim_ConstructorMk1.Anim_ConstructorMk1_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_ConstructorMk1_AnimGraphNode_TransitionResult_56A39FA24B70F097CAE83FB5EF656952
struct UAnim_ConstructorMk1_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_ConstructorMk1_AnimGraphNode_TransitionResult_56A39FA24B70F097CAE83FB5EF656952_Params
{
};

// Function Anim_ConstructorMk1.Anim_ConstructorMk1_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_ConstructorMk1_AnimGraphNode_SequencePlayer_B6B3E67C4FC0B9537DF900A071C952B5
struct UAnim_ConstructorMk1_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_ConstructorMk1_AnimGraphNode_SequencePlayer_B6B3E67C4FC0B9537DF900A071C952B5_Params
{
};

// Function Anim_ConstructorMk1.Anim_ConstructorMk1_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_ConstructorMk1_AnimGraphNode_TransitionResult_1CEFF83543FDFC2AA7280490EC14ED04
struct UAnim_ConstructorMk1_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_ConstructorMk1_AnimGraphNode_TransitionResult_1CEFF83543FDFC2AA7280490EC14ED04_Params
{
};

// Function Anim_ConstructorMk1.Anim_ConstructorMk1_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_ConstructorMk1_AnimGraphNode_TransitionResult_EE25C9DE4FCC24B6648207984D8104F5
struct UAnim_ConstructorMk1_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_ConstructorMk1_AnimGraphNode_TransitionResult_EE25C9DE4FCC24B6648207984D8104F5_Params
{
};

// Function Anim_ConstructorMk1.Anim_ConstructorMk1_C.ExecuteUbergraph_Anim_ConstructorMk1
struct UAnim_ConstructorMk1_C_ExecuteUbergraph_Anim_ConstructorMk1_Params
{
	int                                                EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
