#pragma once

// Satisfactory SDK (V0.1.6 - CL#98445)

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "SF_Basic.hpp"
#include "SF_PhysXVehicles_classes.hpp"
#include "SF_Engine_classes.hpp"
#include "SF_CoreUObject_classes.hpp"
#include "SF_AnimGraphRuntime_classes.hpp"

namespace SDK
{
}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
