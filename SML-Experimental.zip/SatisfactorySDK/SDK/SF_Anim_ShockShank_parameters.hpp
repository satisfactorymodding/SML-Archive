#pragma once

// Satisfactory SDK (V0.1.6 - CL#98445)

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "SF_Anim_ShockShank_classes.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Anim_ShockShank.Anim_ShockShank_C.AnimNotify_Notify_ShockShankAttack
struct UAnim_ShockShank_C_AnimNotify_Notify_ShockShankAttack_Params
{
};

// Function Anim_ShockShank.Anim_ShockShank_C.ExecuteUbergraph_Anim_ShockShank
struct UAnim_ShockShank_C_ExecuteUbergraph_Anim_ShockShank_Params
{
	int                                                EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
