#pragma once

// Satisfactory SDK (V0.1.6 - CL#98445)

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "SF_Anim_SmelterMk1_classes.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Anim_SmelterMk1.Anim_SmelterMk1_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmelterMk1_AnimGraphNode_TransitionResult_E54A44A046F778459C47C3BEC04D653B
struct UAnim_SmelterMk1_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmelterMk1_AnimGraphNode_TransitionResult_E54A44A046F778459C47C3BEC04D653B_Params
{
};

// Function Anim_SmelterMk1.Anim_SmelterMk1_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmelterMk1_AnimGraphNode_TransitionResult_D324C4C649E19CA951526694DDA88E59
struct UAnim_SmelterMk1_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmelterMk1_AnimGraphNode_TransitionResult_D324C4C649E19CA951526694DDA88E59_Params
{
};

// Function Anim_SmelterMk1.Anim_SmelterMk1_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmelterMk1_AnimGraphNode_TransitionResult_D48F108A43361E8AF7D00EA66DCD6902
struct UAnim_SmelterMk1_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmelterMk1_AnimGraphNode_TransitionResult_D48F108A43361E8AF7D00EA66DCD6902_Params
{
};

// Function Anim_SmelterMk1.Anim_SmelterMk1_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmelterMk1_AnimGraphNode_TransitionResult_7E3C44784145321FDF6AB3B9AAD2DF5B
struct UAnim_SmelterMk1_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmelterMk1_AnimGraphNode_TransitionResult_7E3C44784145321FDF6AB3B9AAD2DF5B_Params
{
};

// Function Anim_SmelterMk1.Anim_SmelterMk1_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmelterMk1_AnimGraphNode_SequencePlayer_9D0C0301477072EB7B0BF19477FE60A1
struct UAnim_SmelterMk1_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmelterMk1_AnimGraphNode_SequencePlayer_9D0C0301477072EB7B0BF19477FE60A1_Params
{
};

// Function Anim_SmelterMk1.Anim_SmelterMk1_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmelterMk1_AnimGraphNode_TransitionResult_F28A919E4F948255960F7DAA3AFC2562
struct UAnim_SmelterMk1_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmelterMk1_AnimGraphNode_TransitionResult_F28A919E4F948255960F7DAA3AFC2562_Params
{
};

// Function Anim_SmelterMk1.Anim_SmelterMk1_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmelterMk1_AnimGraphNode_SequencePlayer_CB2083744AC843FC4B34989E6A1BBB72
struct UAnim_SmelterMk1_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmelterMk1_AnimGraphNode_SequencePlayer_CB2083744AC843FC4B34989E6A1BBB72_Params
{
};

// Function Anim_SmelterMk1.Anim_SmelterMk1_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmelterMk1_AnimGraphNode_SequencePlayer_13046FCF4BFFB50B083656B67005044E
struct UAnim_SmelterMk1_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmelterMk1_AnimGraphNode_SequencePlayer_13046FCF4BFFB50B083656B67005044E_Params
{
};

// Function Anim_SmelterMk1.Anim_SmelterMk1_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmelterMk1_AnimGraphNode_TransitionResult_2DB75E584ABD638740D083B155BA2681
struct UAnim_SmelterMk1_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmelterMk1_AnimGraphNode_TransitionResult_2DB75E584ABD638740D083B155BA2681_Params
{
};

// Function Anim_SmelterMk1.Anim_SmelterMk1_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmelterMk1_AnimGraphNode_SequencePlayer_AFB8926E4592012BC47FF2BB5264170D
struct UAnim_SmelterMk1_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_SmelterMk1_AnimGraphNode_SequencePlayer_AFB8926E4592012BC47FF2BB5264170D_Params
{
};

// Function Anim_SmelterMk1.Anim_SmelterMk1_C.AnimNotify_SmelterEnteredProducingState
struct UAnim_SmelterMk1_C_AnimNotify_SmelterEnteredProducingState_Params
{
};

// Function Anim_SmelterMk1.Anim_SmelterMk1_C.AnimNotify_SmelterEnteredOfflineState
struct UAnim_SmelterMk1_C_AnimNotify_SmelterEnteredOfflineState_Params
{
};

// Function Anim_SmelterMk1.Anim_SmelterMk1_C.AnimNotify_SmelterLeftProducingState
struct UAnim_SmelterMk1_C_AnimNotify_SmelterLeftProducingState_Params
{
};

// Function Anim_SmelterMk1.Anim_SmelterMk1_C.AnimNotify_SmelterLeftOfflineState
struct UAnim_SmelterMk1_C_AnimNotify_SmelterLeftOfflineState_Params
{
};

// Function Anim_SmelterMk1.Anim_SmelterMk1_C.ExecuteUbergraph_Anim_SmelterMk1
struct UAnim_SmelterMk1_C_ExecuteUbergraph_Anim_SmelterMk1_Params
{
	int                                                EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
