#pragma once

// Satisfactory SDK (V0.1.6 - CL#98445)

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "SF_Anim_GeneratorBiomass_classes.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Anim_GeneratorBiomass.Anim_GeneratorBiomass_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_GeneratorBiomass_AnimGraphNode_SequencePlayer_0C8C552E4E287DB760E798963A4A3A89
struct UAnim_GeneratorBiomass_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_GeneratorBiomass_AnimGraphNode_SequencePlayer_0C8C552E4E287DB760E798963A4A3A89_Params
{
};

// Function Anim_GeneratorBiomass.Anim_GeneratorBiomass_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_GeneratorBiomass_AnimGraphNode_SequencePlayer_2ED3BC44427082C2C1A5579744016E05
struct UAnim_GeneratorBiomass_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_GeneratorBiomass_AnimGraphNode_SequencePlayer_2ED3BC44427082C2C1A5579744016E05_Params
{
};

// Function Anim_GeneratorBiomass.Anim_GeneratorBiomass_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_GeneratorBiomass_AnimGraphNode_TransitionResult_200821834ED7CC79F3EAFA9DCC5FD9C9
struct UAnim_GeneratorBiomass_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_GeneratorBiomass_AnimGraphNode_TransitionResult_200821834ED7CC79F3EAFA9DCC5FD9C9_Params
{
};

// Function Anim_GeneratorBiomass.Anim_GeneratorBiomass_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_GeneratorBiomass_AnimGraphNode_TransitionResult_37B6A3A14ECFCC343640839E675CE96C
struct UAnim_GeneratorBiomass_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_GeneratorBiomass_AnimGraphNode_TransitionResult_37B6A3A14ECFCC343640839E675CE96C_Params
{
};

// Function Anim_GeneratorBiomass.Anim_GeneratorBiomass_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_GeneratorBiomass_AnimGraphNode_TransitionResult_4B189C36454C9859982E0C952C56A826
struct UAnim_GeneratorBiomass_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_GeneratorBiomass_AnimGraphNode_TransitionResult_4B189C36454C9859982E0C952C56A826_Params
{
};

// Function Anim_GeneratorBiomass.Anim_GeneratorBiomass_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_GeneratorBiomass_AnimGraphNode_TransitionResult_D3A05BC8479337B7F6A46E8AAF268913
struct UAnim_GeneratorBiomass_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_GeneratorBiomass_AnimGraphNode_TransitionResult_D3A05BC8479337B7F6A46E8AAF268913_Params
{
};

// Function Anim_GeneratorBiomass.Anim_GeneratorBiomass_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_GeneratorBiomass_AnimGraphNode_TransitionResult_24E56DBB4C9CB310B87E15AC34FA2026
struct UAnim_GeneratorBiomass_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_GeneratorBiomass_AnimGraphNode_TransitionResult_24E56DBB4C9CB310B87E15AC34FA2026_Params
{
};

// Function Anim_GeneratorBiomass.Anim_GeneratorBiomass_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_GeneratorBiomass_AnimGraphNode_TransitionResult_279239284AD911AD6AC2B1BED4851122
struct UAnim_GeneratorBiomass_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_GeneratorBiomass_AnimGraphNode_TransitionResult_279239284AD911AD6AC2B1BED4851122_Params
{
};

// Function Anim_GeneratorBiomass.Anim_GeneratorBiomass_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_GeneratorBiomass_AnimGraphNode_TransitionResult_1617BEC2426F4BC70FB70A8BE7A712F7
struct UAnim_GeneratorBiomass_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_GeneratorBiomass_AnimGraphNode_TransitionResult_1617BEC2426F4BC70FB70A8BE7A712F7_Params
{
};

// Function Anim_GeneratorBiomass.Anim_GeneratorBiomass_C.AnimNotify_SteamFxNotify
struct UAnim_GeneratorBiomass_C_AnimNotify_SteamFxNotify_Params
{
};

// Function Anim_GeneratorBiomass.Anim_GeneratorBiomass_C.AnimNotify_SteamFxNotify_02
struct UAnim_GeneratorBiomass_C_AnimNotify_SteamFxNotify_02_Params
{
};

// Function Anim_GeneratorBiomass.Anim_GeneratorBiomass_C.AnimNotify_SteamFxNotify_03
struct UAnim_GeneratorBiomass_C_AnimNotify_SteamFxNotify_03_Params
{
};

// Function Anim_GeneratorBiomass.Anim_GeneratorBiomass_C.AnimNotify_SteamFxNotify_04
struct UAnim_GeneratorBiomass_C_AnimNotify_SteamFxNotify_04_Params
{
};

// Function Anim_GeneratorBiomass.Anim_GeneratorBiomass_C.AnimNotify_SteamFxNotify_05
struct UAnim_GeneratorBiomass_C_AnimNotify_SteamFxNotify_05_Params
{
};

// Function Anim_GeneratorBiomass.Anim_GeneratorBiomass_C.AnimNotify_SteamFxNotify_06
struct UAnim_GeneratorBiomass_C_AnimNotify_SteamFxNotify_06_Params
{
};

// Function Anim_GeneratorBiomass.Anim_GeneratorBiomass_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_GeneratorBiomass_AnimGraphNode_SequencePlayer_C99B07D2448770B3F327DEA5D0DE1957
struct UAnim_GeneratorBiomass_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_GeneratorBiomass_AnimGraphNode_SequencePlayer_C99B07D2448770B3F327DEA5D0DE1957_Params
{
};

// Function Anim_GeneratorBiomass.Anim_GeneratorBiomass_C.AnimNotify_BioGenEnteredProducingState
struct UAnim_GeneratorBiomass_C_AnimNotify_BioGenEnteredProducingState_Params
{
};

// Function Anim_GeneratorBiomass.Anim_GeneratorBiomass_C.AnimNotify_BioGenLeftProducingState
struct UAnim_GeneratorBiomass_C_AnimNotify_BioGenLeftProducingState_Params
{
};

// Function Anim_GeneratorBiomass.Anim_GeneratorBiomass_C.AnimNotify_BioGenEnteredFunnelPoweredState
struct UAnim_GeneratorBiomass_C_AnimNotify_BioGenEnteredFunnelPoweredState_Params
{
};

// Function Anim_GeneratorBiomass.Anim_GeneratorBiomass_C.AnimNotify_BioGenEnteredFunnelShutdownState
struct UAnim_GeneratorBiomass_C_AnimNotify_BioGenEnteredFunnelShutdownState_Params
{
};

// Function Anim_GeneratorBiomass.Anim_GeneratorBiomass_C.ExecuteUbergraph_Anim_GeneratorBiomass
struct UAnim_GeneratorBiomass_C_ExecuteUbergraph_Anim_GeneratorBiomass_Params
{
	int                                                EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
