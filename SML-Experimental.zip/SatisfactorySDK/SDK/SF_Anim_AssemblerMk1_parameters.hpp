#pragma once

// Satisfactory SDK (V0.1.6 - CL#98445)

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "SF_Anim_AssemblerMk1_classes.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Anim_AssemblerMk1.Anim_AssemblerMk1_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_AssemblerMk1_AnimGraphNode_TransitionResult_FA27F5364EEE23A8397146AC807D7382
struct UAnim_AssemblerMk1_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_AssemblerMk1_AnimGraphNode_TransitionResult_FA27F5364EEE23A8397146AC807D7382_Params
{
};

// Function Anim_AssemblerMk1.Anim_AssemblerMk1_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_AssemblerMk1_AnimGraphNode_TransitionResult_6CF0064D49FFA3F68E2157B24CA90C53
struct UAnim_AssemblerMk1_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_AssemblerMk1_AnimGraphNode_TransitionResult_6CF0064D49FFA3F68E2157B24CA90C53_Params
{
};

// Function Anim_AssemblerMk1.Anim_AssemblerMk1_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_AssemblerMk1_AnimGraphNode_TransitionResult_365546E5468F7D51DA09588D93F38BF3
struct UAnim_AssemblerMk1_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_AssemblerMk1_AnimGraphNode_TransitionResult_365546E5468F7D51DA09588D93F38BF3_Params
{
};

// Function Anim_AssemblerMk1.Anim_AssemblerMk1_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_AssemblerMk1_AnimGraphNode_SequenceEvaluator_5027BAA6431E22FD1996349AC52F508E
struct UAnim_AssemblerMk1_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_AssemblerMk1_AnimGraphNode_SequenceEvaluator_5027BAA6431E22FD1996349AC52F508E_Params
{
};

// Function Anim_AssemblerMk1.Anim_AssemblerMk1_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_AssemblerMk1_AnimGraphNode_TransitionResult_75337FF64C7BF9E85FCD219C4EE5BE12
struct UAnim_AssemblerMk1_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_AssemblerMk1_AnimGraphNode_TransitionResult_75337FF64C7BF9E85FCD219C4EE5BE12_Params
{
};

// Function Anim_AssemblerMk1.Anim_AssemblerMk1_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_AssemblerMk1_AnimGraphNode_SequencePlayer_2F5CBA174512BE052C68FDBFE9E8F1EE
struct UAnim_AssemblerMk1_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_AssemblerMk1_AnimGraphNode_SequencePlayer_2F5CBA174512BE052C68FDBFE9E8F1EE_Params
{
};

// Function Anim_AssemblerMk1.Anim_AssemblerMk1_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_AssemblerMk1_AnimGraphNode_TransitionResult_8FA2DFAB4BE52C1147B22ABACB8EDBAB
struct UAnim_AssemblerMk1_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_AssemblerMk1_AnimGraphNode_TransitionResult_8FA2DFAB4BE52C1147B22ABACB8EDBAB_Params
{
};

// Function Anim_AssemblerMk1.Anim_AssemblerMk1_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_AssemblerMk1_AnimGraphNode_SequencePlayer_F3566A874DF4FDFBF2575783CBC26D17
struct UAnim_AssemblerMk1_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_AssemblerMk1_AnimGraphNode_SequencePlayer_F3566A874DF4FDFBF2575783CBC26D17_Params
{
};

// Function Anim_AssemblerMk1.Anim_AssemblerMk1_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_AssemblerMk1_AnimGraphNode_SequencePlayer_40C151D74ADB3B29325C05934D92531B
struct UAnim_AssemblerMk1_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_AssemblerMk1_AnimGraphNode_SequencePlayer_40C151D74ADB3B29325C05934D92531B_Params
{
};

// Function Anim_AssemblerMk1.Anim_AssemblerMk1_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_AssemblerMk1_AnimGraphNode_TransitionResult_E99EF37543BC9BEE7259B7A04276781C
struct UAnim_AssemblerMk1_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_AssemblerMk1_AnimGraphNode_TransitionResult_E99EF37543BC9BEE7259B7A04276781C_Params
{
};

// Function Anim_AssemblerMk1.Anim_AssemblerMk1_C.ExecuteUbergraph_Anim_AssemblerMk1
struct UAnim_AssemblerMk1_C_ExecuteUbergraph_Anim_AssemblerMk1_Params
{
	int                                                EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
