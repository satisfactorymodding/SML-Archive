// Satisfactory SDK (V0.1.6 - CL#98445)

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "SF_Anim_OilRefinery_parameters.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function Anim_OilRefinery.Anim_OilRefinery_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_OilRefinery_AnimGraphNode_TransitionResult_771BDC794315C97B9114B58B67D53B9B
// ()

void UAnim_OilRefinery_C::EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_OilRefinery_AnimGraphNode_TransitionResult_771BDC794315C97B9114B58B67D53B9B()
{
	static auto fn = UObject::FindObject<UFunction>("Function Anim_OilRefinery.Anim_OilRefinery_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_OilRefinery_AnimGraphNode_TransitionResult_771BDC794315C97B9114B58B67D53B9B");

	UAnim_OilRefinery_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_OilRefinery_AnimGraphNode_TransitionResult_771BDC794315C97B9114B58B67D53B9B_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function Anim_OilRefinery.Anim_OilRefinery_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_OilRefinery_AnimGraphNode_TransitionResult_915C10B24BBBA51A6DF22CA3D0A78740
// ()

void UAnim_OilRefinery_C::EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_OilRefinery_AnimGraphNode_TransitionResult_915C10B24BBBA51A6DF22CA3D0A78740()
{
	static auto fn = UObject::FindObject<UFunction>("Function Anim_OilRefinery.Anim_OilRefinery_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_OilRefinery_AnimGraphNode_TransitionResult_915C10B24BBBA51A6DF22CA3D0A78740");

	UAnim_OilRefinery_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_OilRefinery_AnimGraphNode_TransitionResult_915C10B24BBBA51A6DF22CA3D0A78740_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function Anim_OilRefinery.Anim_OilRefinery_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_OilRefinery_AnimGraphNode_SequencePlayer_F1EFB75748441598AB354FA6C373C89A
// ()

void UAnim_OilRefinery_C::EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_OilRefinery_AnimGraphNode_SequencePlayer_F1EFB75748441598AB354FA6C373C89A()
{
	static auto fn = UObject::FindObject<UFunction>("Function Anim_OilRefinery.Anim_OilRefinery_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_OilRefinery_AnimGraphNode_SequencePlayer_F1EFB75748441598AB354FA6C373C89A");

	UAnim_OilRefinery_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_OilRefinery_AnimGraphNode_SequencePlayer_F1EFB75748441598AB354FA6C373C89A_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function Anim_OilRefinery.Anim_OilRefinery_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_OilRefinery_AnimGraphNode_TransitionResult_ADC926934470782C4CC4E4AA0FAF9BD1
// ()

void UAnim_OilRefinery_C::EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_OilRefinery_AnimGraphNode_TransitionResult_ADC926934470782C4CC4E4AA0FAF9BD1()
{
	static auto fn = UObject::FindObject<UFunction>("Function Anim_OilRefinery.Anim_OilRefinery_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_OilRefinery_AnimGraphNode_TransitionResult_ADC926934470782C4CC4E4AA0FAF9BD1");

	UAnim_OilRefinery_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_OilRefinery_AnimGraphNode_TransitionResult_ADC926934470782C4CC4E4AA0FAF9BD1_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function Anim_OilRefinery.Anim_OilRefinery_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_OilRefinery_AnimGraphNode_SequencePlayer_13C879DC4AE2357A23B328B1442B4914
// ()

void UAnim_OilRefinery_C::EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_OilRefinery_AnimGraphNode_SequencePlayer_13C879DC4AE2357A23B328B1442B4914()
{
	static auto fn = UObject::FindObject<UFunction>("Function Anim_OilRefinery.Anim_OilRefinery_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_OilRefinery_AnimGraphNode_SequencePlayer_13C879DC4AE2357A23B328B1442B4914");

	UAnim_OilRefinery_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_OilRefinery_AnimGraphNode_SequencePlayer_13C879DC4AE2357A23B328B1442B4914_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function Anim_OilRefinery.Anim_OilRefinery_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_OilRefinery_AnimGraphNode_SequencePlayer_049CFCF849B615B553EE89B9F2D39FC7
// ()

void UAnim_OilRefinery_C::EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_OilRefinery_AnimGraphNode_SequencePlayer_049CFCF849B615B553EE89B9F2D39FC7()
{
	static auto fn = UObject::FindObject<UFunction>("Function Anim_OilRefinery.Anim_OilRefinery_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_OilRefinery_AnimGraphNode_SequencePlayer_049CFCF849B615B553EE89B9F2D39FC7");

	UAnim_OilRefinery_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_OilRefinery_AnimGraphNode_SequencePlayer_049CFCF849B615B553EE89B9F2D39FC7_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function Anim_OilRefinery.Anim_OilRefinery_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_OilRefinery_AnimGraphNode_TransitionResult_00E703984606D1BEF63D9A807E113CCD
// ()

void UAnim_OilRefinery_C::EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_OilRefinery_AnimGraphNode_TransitionResult_00E703984606D1BEF63D9A807E113CCD()
{
	static auto fn = UObject::FindObject<UFunction>("Function Anim_OilRefinery.Anim_OilRefinery_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_OilRefinery_AnimGraphNode_TransitionResult_00E703984606D1BEF63D9A807E113CCD");

	UAnim_OilRefinery_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_OilRefinery_AnimGraphNode_TransitionResult_00E703984606D1BEF63D9A807E113CCD_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function Anim_OilRefinery.Anim_OilRefinery_C.AnimNotify_OilRefineryEnteredOffline
// ()

void UAnim_OilRefinery_C::AnimNotify_OilRefineryEnteredOffline()
{
	static auto fn = UObject::FindObject<UFunction>("Function Anim_OilRefinery.Anim_OilRefinery_C.AnimNotify_OilRefineryEnteredOffline");

	UAnim_OilRefinery_C_AnimNotify_OilRefineryEnteredOffline_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function Anim_OilRefinery.Anim_OilRefinery_C.AnimNotify_OilRefineryEnteredProducing
// ()

void UAnim_OilRefinery_C::AnimNotify_OilRefineryEnteredProducing()
{
	static auto fn = UObject::FindObject<UFunction>("Function Anim_OilRefinery.Anim_OilRefinery_C.AnimNotify_OilRefineryEnteredProducing");

	UAnim_OilRefinery_C_AnimNotify_OilRefineryEnteredProducing_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function Anim_OilRefinery.Anim_OilRefinery_C.AnimNotify_OilRefineryLeftOffline
// ()

void UAnim_OilRefinery_C::AnimNotify_OilRefineryLeftOffline()
{
	static auto fn = UObject::FindObject<UFunction>("Function Anim_OilRefinery.Anim_OilRefinery_C.AnimNotify_OilRefineryLeftOffline");

	UAnim_OilRefinery_C_AnimNotify_OilRefineryLeftOffline_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function Anim_OilRefinery.Anim_OilRefinery_C.AnimNotify_OilRefineryLeftProducing
// ()

void UAnim_OilRefinery_C::AnimNotify_OilRefineryLeftProducing()
{
	static auto fn = UObject::FindObject<UFunction>("Function Anim_OilRefinery.Anim_OilRefinery_C.AnimNotify_OilRefineryLeftProducing");

	UAnim_OilRefinery_C_AnimNotify_OilRefineryLeftProducing_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function Anim_OilRefinery.Anim_OilRefinery_C.ExecuteUbergraph_Anim_OilRefinery
// ()
// Parameters:
// int                            EntryPoint                     (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)

void UAnim_OilRefinery_C::ExecuteUbergraph_Anim_OilRefinery(int EntryPoint)
{
	static auto fn = UObject::FindObject<UFunction>("Function Anim_OilRefinery.Anim_OilRefinery_C.ExecuteUbergraph_Anim_OilRefinery");

	UAnim_OilRefinery_C_ExecuteUbergraph_Anim_OilRefinery_Params params;
	params.EntryPoint = EntryPoint;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
