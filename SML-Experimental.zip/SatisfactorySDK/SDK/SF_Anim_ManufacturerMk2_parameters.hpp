#pragma once

// Satisfactory SDK (V0.1.6 - CL#98445)

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "SF_Anim_ManufacturerMk2_classes.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Anim_ManufacturerMk2.Anim_ManufacturerMk2_C.AnimNotify_ConstructorComplexIndustrialLeftOfflineState
struct UAnim_ManufacturerMk2_C_AnimNotify_ConstructorComplexIndustrialLeftOfflineState_Params
{
};

// Function Anim_ManufacturerMk2.Anim_ManufacturerMk2_C.AnimNotify_ConstructorComplexIndustrialEnteredProducingState
struct UAnim_ManufacturerMk2_C_AnimNotify_ConstructorComplexIndustrialEnteredProducingState_Params
{
};

// Function Anim_ManufacturerMk2.Anim_ManufacturerMk2_C.AnimNotify_ConstructorComplexIndustrialLeftProducingState
struct UAnim_ManufacturerMk2_C_AnimNotify_ConstructorComplexIndustrialLeftProducingState_Params
{
};

// Function Anim_ManufacturerMk2.Anim_ManufacturerMk2_C.AnimNotify_ConstructorComplexIndustrialEnteredOfflineState
struct UAnim_ManufacturerMk2_C_AnimNotify_ConstructorComplexIndustrialEnteredOfflineState_Params
{
};

// Function Anim_ManufacturerMk2.Anim_ManufacturerMk2_C.ExecuteUbergraph_Anim_ManufacturerMk2
struct UAnim_ManufacturerMk2_C_ExecuteUbergraph_Anim_ManufacturerMk2_Params
{
	int                                                EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
