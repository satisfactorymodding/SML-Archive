#pragma once

// Satisfactory SDK (V0.1.6 - CL#98445)

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "SF_Anim_FoundryMk1_classes.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Anim_FoundryMk1.Anim_FoundryMk1_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_FoundryMk1_AnimGraphNode_TransitionResult_876F9B534B833CD716FA7F8814C9D609
struct UAnim_FoundryMk1_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_FoundryMk1_AnimGraphNode_TransitionResult_876F9B534B833CD716FA7F8814C9D609_Params
{
};

// Function Anim_FoundryMk1.Anim_FoundryMk1_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_FoundryMk1_AnimGraphNode_TransitionResult_6E7B20B247A5AE6DE15E2BA7C8C417CF
struct UAnim_FoundryMk1_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_FoundryMk1_AnimGraphNode_TransitionResult_6E7B20B247A5AE6DE15E2BA7C8C417CF_Params
{
};

// Function Anim_FoundryMk1.Anim_FoundryMk1_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_FoundryMk1_AnimGraphNode_TransitionResult_1E0973BE4289C059C8FF2CABCF32BB11
struct UAnim_FoundryMk1_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_FoundryMk1_AnimGraphNode_TransitionResult_1E0973BE4289C059C8FF2CABCF32BB11_Params
{
};

// Function Anim_FoundryMk1.Anim_FoundryMk1_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_FoundryMk1_AnimGraphNode_TransitionResult_478A0DF447B868D2D5D7B8B1BCBFEA0B
struct UAnim_FoundryMk1_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_FoundryMk1_AnimGraphNode_TransitionResult_478A0DF447B868D2D5D7B8B1BCBFEA0B_Params
{
};

// Function Anim_FoundryMk1.Anim_FoundryMk1_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_FoundryMk1_AnimGraphNode_SequencePlayer_D76E953F4ECE2FB3E148CAB4DF336CD9
struct UAnim_FoundryMk1_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_FoundryMk1_AnimGraphNode_SequencePlayer_D76E953F4ECE2FB3E148CAB4DF336CD9_Params
{
};

// Function Anim_FoundryMk1.Anim_FoundryMk1_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_FoundryMk1_AnimGraphNode_TransitionResult_82F9EFE444AF4500E522FEB1918EDC3E
struct UAnim_FoundryMk1_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_FoundryMk1_AnimGraphNode_TransitionResult_82F9EFE444AF4500E522FEB1918EDC3E_Params
{
};

// Function Anim_FoundryMk1.Anim_FoundryMk1_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_FoundryMk1_AnimGraphNode_SequencePlayer_CC84A083460E556F599A68B6C142D420
struct UAnim_FoundryMk1_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_FoundryMk1_AnimGraphNode_SequencePlayer_CC84A083460E556F599A68B6C142D420_Params
{
};

// Function Anim_FoundryMk1.Anim_FoundryMk1_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_FoundryMk1_AnimGraphNode_TransitionResult_250E7CB949C86C034EBAA98E3DB7BF38
struct UAnim_FoundryMk1_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_FoundryMk1_AnimGraphNode_TransitionResult_250E7CB949C86C034EBAA98E3DB7BF38_Params
{
};

// Function Anim_FoundryMk1.Anim_FoundryMk1_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_FoundryMk1_AnimGraphNode_SequencePlayer_45FEB52E45768294FDA1B09B58E87AC5
struct UAnim_FoundryMk1_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_FoundryMk1_AnimGraphNode_SequencePlayer_45FEB52E45768294FDA1B09B58E87AC5_Params
{
};

// Function Anim_FoundryMk1.Anim_FoundryMk1_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_FoundryMk1_AnimGraphNode_SequencePlayer_B5C2E72F498DC4EE16577A97413B0785
struct UAnim_FoundryMk1_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_FoundryMk1_AnimGraphNode_SequencePlayer_B5C2E72F498DC4EE16577A97413B0785_Params
{
};

// Function Anim_FoundryMk1.Anim_FoundryMk1_C.AnimNotify_SmelterEnteredProducingState
struct UAnim_FoundryMk1_C_AnimNotify_SmelterEnteredProducingState_Params
{
};

// Function Anim_FoundryMk1.Anim_FoundryMk1_C.AnimNotify_SmelterEnteredOfflineState
struct UAnim_FoundryMk1_C_AnimNotify_SmelterEnteredOfflineState_Params
{
};

// Function Anim_FoundryMk1.Anim_FoundryMk1_C.AnimNotify_SmelterLeftProducingState
struct UAnim_FoundryMk1_C_AnimNotify_SmelterLeftProducingState_Params
{
};

// Function Anim_FoundryMk1.Anim_FoundryMk1_C.AnimNotify_SmelterLeftOfflineState
struct UAnim_FoundryMk1_C_AnimNotify_SmelterLeftOfflineState_Params
{
};

// Function Anim_FoundryMk1.Anim_FoundryMk1_C.ExecuteUbergraph_Anim_FoundryMk1
struct UAnim_FoundryMk1_C_ExecuteUbergraph_Anim_FoundryMk1_Params
{
	int                                                EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
