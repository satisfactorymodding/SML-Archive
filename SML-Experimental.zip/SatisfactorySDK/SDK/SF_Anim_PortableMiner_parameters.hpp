#pragma once

// Satisfactory SDK (V0.1.6 - CL#98445)

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "SF_Anim_PortableMiner_classes.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Anim_PortableMiner.Anim_PortableMiner_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_PortableMiner_AnimGraphNode_TransitionResult_9F22980F4C75DDCB8844E7AD5E61A50E
struct UAnim_PortableMiner_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_PortableMiner_AnimGraphNode_TransitionResult_9F22980F4C75DDCB8844E7AD5E61A50E_Params
{
};

// Function Anim_PortableMiner.Anim_PortableMiner_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_PortableMiner_AnimGraphNode_TransitionResult_73CC830A4A7FA7DBD81A0A8D8F99E468
struct UAnim_PortableMiner_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_PortableMiner_AnimGraphNode_TransitionResult_73CC830A4A7FA7DBD81A0A8D8F99E468_Params
{
};

// Function Anim_PortableMiner.Anim_PortableMiner_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_PortableMiner_AnimGraphNode_TransitionResult_15450DBB48F88D37E85553A4CB1AD445
struct UAnim_PortableMiner_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_PortableMiner_AnimGraphNode_TransitionResult_15450DBB48F88D37E85553A4CB1AD445_Params
{
};

// Function Anim_PortableMiner.Anim_PortableMiner_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_PortableMiner_AnimGraphNode_SequencePlayer_91E544B14F208DE687641AB79478B8F4
struct UAnim_PortableMiner_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_PortableMiner_AnimGraphNode_SequencePlayer_91E544B14F208DE687641AB79478B8F4_Params
{
};

// Function Anim_PortableMiner.Anim_PortableMiner_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_PortableMiner_AnimGraphNode_SequencePlayer_70241D21426D7B3B7D1B42B9CB547268
struct UAnim_PortableMiner_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_PortableMiner_AnimGraphNode_SequencePlayer_70241D21426D7B3B7D1B42B9CB547268_Params
{
};

// Function Anim_PortableMiner.Anim_PortableMiner_C.BlueprintUpdateAnimation
struct UAnim_PortableMiner_C_BlueprintUpdateAnimation_Params
{
	float*                                             DeltaTimeX;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Anim_PortableMiner.Anim_PortableMiner_C.AnimNotify_StartMiningVfxNotify
struct UAnim_PortableMiner_C_AnimNotify_StartMiningVfxNotify_Params
{
};

// Function Anim_PortableMiner.Anim_PortableMiner_C.AnimNotify_PortableMinerEnteredOfflineState
struct UAnim_PortableMiner_C_AnimNotify_PortableMinerEnteredOfflineState_Params
{
};

// Function Anim_PortableMiner.Anim_PortableMiner_C.AnimNotify_PortableMinerLeftOfflineState
struct UAnim_PortableMiner_C_AnimNotify_PortableMinerLeftOfflineState_Params
{
};

// Function Anim_PortableMiner.Anim_PortableMiner_C.AnimNotify_StartBurnerVfxNotify
struct UAnim_PortableMiner_C_AnimNotify_StartBurnerVfxNotify_Params
{
};

// Function Anim_PortableMiner.Anim_PortableMiner_C.ExecuteUbergraph_Anim_PortableMiner
struct UAnim_PortableMiner_C_ExecuteUbergraph_Anim_PortableMiner_Params
{
	int                                                EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
