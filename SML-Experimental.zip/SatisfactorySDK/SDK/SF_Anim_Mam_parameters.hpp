#pragma once

// Satisfactory SDK (V0.1.6 - CL#98445)

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "SF_Anim_Mam_classes.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Anim_Mam.Anim_Mam_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_Mam_AnimGraphNode_TransitionResult_7B42FA4D4C5AE3B0E0A785B67992E8C9
struct UAnim_Mam_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_Mam_AnimGraphNode_TransitionResult_7B42FA4D4C5AE3B0E0A785B67992E8C9_Params
{
};

// Function Anim_Mam.Anim_Mam_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_Mam_AnimGraphNode_TransitionResult_8A2BB1DC482B62F6D6BFDB8864303B73
struct UAnim_Mam_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_Mam_AnimGraphNode_TransitionResult_8A2BB1DC482B62F6D6BFDB8864303B73_Params
{
};

// Function Anim_Mam.Anim_Mam_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_Mam_AnimGraphNode_SequencePlayer_167D778F4E8F21A00AAF45A719F92437
struct UAnim_Mam_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_Mam_AnimGraphNode_SequencePlayer_167D778F4E8F21A00AAF45A719F92437_Params
{
};

// Function Anim_Mam.Anim_Mam_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_Mam_AnimGraphNode_TransitionResult_8CA4CF194793432BEFBFA48EC6C1D6B4
struct UAnim_Mam_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_Mam_AnimGraphNode_TransitionResult_8CA4CF194793432BEFBFA48EC6C1D6B4_Params
{
};

// Function Anim_Mam.Anim_Mam_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_Mam_AnimGraphNode_TransitionResult_09AFEC37414DF06BB3F61FA584003AF6
struct UAnim_Mam_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_Mam_AnimGraphNode_TransitionResult_09AFEC37414DF06BB3F61FA584003AF6_Params
{
};

// Function Anim_Mam.Anim_Mam_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_Mam_AnimGraphNode_SequencePlayer_F0E0C19C4D9A0EECDC4E11A6A9EDB1AD
struct UAnim_Mam_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_Mam_AnimGraphNode_SequencePlayer_F0E0C19C4D9A0EECDC4E11A6A9EDB1AD_Params
{
};

// Function Anim_Mam.Anim_Mam_C.BlueprintUpdateAnimation
struct UAnim_Mam_C_BlueprintUpdateAnimation_Params
{
	float*                                             DeltaTimeX;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Anim_Mam.Anim_Mam_C.BlueprintInitializeAnimation
struct UAnim_Mam_C_BlueprintInitializeAnimation_Params
{
};

// Function Anim_Mam.Anim_Mam_C.HasPowerChanged
struct UAnim_Mam_C_HasPowerChanged_Params
{
	bool                                               State;                                                    // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Anim_Mam.Anim_Mam_C.AnimNotify_MamEnteredProducing
struct UAnim_Mam_C_AnimNotify_MamEnteredProducing_Params
{
};

// Function Anim_Mam.Anim_Mam_C.AnimNotify_MamLeftProducing
struct UAnim_Mam_C_AnimNotify_MamLeftProducing_Params
{
};

// Function Anim_Mam.Anim_Mam_C.BlueprintBeginPlay
struct UAnim_Mam_C_BlueprintBeginPlay_Params
{
};

// Function Anim_Mam.Anim_Mam_C.ExecuteUbergraph_Anim_Mam
struct UAnim_Mam_C_ExecuteUbergraph_Anim_Mam_Params
{
	int                                                EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
