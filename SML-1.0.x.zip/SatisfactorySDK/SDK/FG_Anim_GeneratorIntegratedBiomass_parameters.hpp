#pragma once

// Satisfactory SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "FG_Anim_GeneratorIntegratedBiomass_classes.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Anim_GeneratorIntegratedBiomass.Anim_GeneratorIntegratedBiomass_C.AnimNotify_SteamFxNotify
struct UAnim_GeneratorIntegratedBiomass_C_AnimNotify_SteamFxNotify_Params
{
};

// Function Anim_GeneratorIntegratedBiomass.Anim_GeneratorIntegratedBiomass_C.AnimNotify_SteamFxNotify_02
struct UAnim_GeneratorIntegratedBiomass_C_AnimNotify_SteamFxNotify_02_Params
{
};

// Function Anim_GeneratorIntegratedBiomass.Anim_GeneratorIntegratedBiomass_C.AnimNotify_SteamFxNotify_03
struct UAnim_GeneratorIntegratedBiomass_C_AnimNotify_SteamFxNotify_03_Params
{
};

// Function Anim_GeneratorIntegratedBiomass.Anim_GeneratorIntegratedBiomass_C.AnimNotify_SteamFxNotify_04
struct UAnim_GeneratorIntegratedBiomass_C_AnimNotify_SteamFxNotify_04_Params
{
};

// Function Anim_GeneratorIntegratedBiomass.Anim_GeneratorIntegratedBiomass_C.AnimNotify_SteamFxNotify_05
struct UAnim_GeneratorIntegratedBiomass_C_AnimNotify_SteamFxNotify_05_Params
{
};

// Function Anim_GeneratorIntegratedBiomass.Anim_GeneratorIntegratedBiomass_C.AnimNotify_SteamFxNotify_06
struct UAnim_GeneratorIntegratedBiomass_C_AnimNotify_SteamFxNotify_06_Params
{
};

// Function Anim_GeneratorIntegratedBiomass.Anim_GeneratorIntegratedBiomass_C.AnimNotify_BioGenEnteredProducingState
struct UAnim_GeneratorIntegratedBiomass_C_AnimNotify_BioGenEnteredProducingState_Params
{
};

// Function Anim_GeneratorIntegratedBiomass.Anim_GeneratorIntegratedBiomass_C.AnimNotify_BioGenLeftProducingState
struct UAnim_GeneratorIntegratedBiomass_C_AnimNotify_BioGenLeftProducingState_Params
{
};

// Function Anim_GeneratorIntegratedBiomass.Anim_GeneratorIntegratedBiomass_C.AnimNotify_BioGenEnteredFunnelPoweredState
struct UAnim_GeneratorIntegratedBiomass_C_AnimNotify_BioGenEnteredFunnelPoweredState_Params
{
};

// Function Anim_GeneratorIntegratedBiomass.Anim_GeneratorIntegratedBiomass_C.AnimNotify_BioGenEnteredFunnelShutdownState
struct UAnim_GeneratorIntegratedBiomass_C_AnimNotify_BioGenEnteredFunnelShutdownState_Params
{
};

// Function Anim_GeneratorIntegratedBiomass.Anim_GeneratorIntegratedBiomass_C.ExecuteUbergraph_Anim_GeneratorIntegratedBiomass
struct UAnim_GeneratorIntegratedBiomass_C_ExecuteUbergraph_Anim_GeneratorIntegratedBiomass_Params
{
	int                                                EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
