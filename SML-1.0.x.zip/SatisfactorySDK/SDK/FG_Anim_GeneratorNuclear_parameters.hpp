#pragma once

// Satisfactory SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "FG_Anim_GeneratorNuclear_classes.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Anim_GeneratorNuclear.Anim_GeneratorNuclear_C.SetupReloadTimer
struct UAnim_GeneratorNuclear_C_SetupReloadTimer_Params
{
};

// Function Anim_GeneratorNuclear.Anim_GeneratorNuclear_C.ReloadTimer
struct UAnim_GeneratorNuclear_C_ReloadTimer_Params
{
};

// Function Anim_GeneratorNuclear.Anim_GeneratorNuclear_C.AnimNotify_GenNuclearEnteredReloadState
struct UAnim_GeneratorNuclear_C_AnimNotify_GenNuclearEnteredReloadState_Params
{
};

// Function Anim_GeneratorNuclear.Anim_GeneratorNuclear_C.AnimNotify_GenNuclearStartupVfx
struct UAnim_GeneratorNuclear_C_AnimNotify_GenNuclearStartupVfx_Params
{
};

// Function Anim_GeneratorNuclear.Anim_GeneratorNuclear_C.AnimNotify_GenNuclearShutdownVfx
struct UAnim_GeneratorNuclear_C_AnimNotify_GenNuclearShutdownVfx_Params
{
};

// Function Anim_GeneratorNuclear.Anim_GeneratorNuclear_C.AnimNotify_GenNuclearEnteredProducing
struct UAnim_GeneratorNuclear_C_AnimNotify_GenNuclearEnteredProducing_Params
{
};

// Function Anim_GeneratorNuclear.Anim_GeneratorNuclear_C.AnimNotify_GenNuclearLeftProducing
struct UAnim_GeneratorNuclear_C_AnimNotify_GenNuclearLeftProducing_Params
{
};

// Function Anim_GeneratorNuclear.Anim_GeneratorNuclear_C.ExecuteUbergraph_Anim_GeneratorNuclear
struct UAnim_GeneratorNuclear_C_ExecuteUbergraph_Anim_GeneratorNuclear_Params
{
	int                                                EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
