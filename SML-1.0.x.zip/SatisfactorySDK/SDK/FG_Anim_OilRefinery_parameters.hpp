#pragma once

// Satisfactory SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "FG_Anim_OilRefinery_classes.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Anim_OilRefinery.Anim_OilRefinery_C.AnimNotify_OilRefineryEnteredOffline
struct UAnim_OilRefinery_C_AnimNotify_OilRefineryEnteredOffline_Params
{
};

// Function Anim_OilRefinery.Anim_OilRefinery_C.AnimNotify_OilRefineryEnteredProducing
struct UAnim_OilRefinery_C_AnimNotify_OilRefineryEnteredProducing_Params
{
};

// Function Anim_OilRefinery.Anim_OilRefinery_C.AnimNotify_OilRefineryLeftOffline
struct UAnim_OilRefinery_C_AnimNotify_OilRefineryLeftOffline_Params
{
};

// Function Anim_OilRefinery.Anim_OilRefinery_C.AnimNotify_OilRefineryLeftProducing
struct UAnim_OilRefinery_C_AnimNotify_OilRefineryLeftProducing_Params
{
};

// Function Anim_OilRefinery.Anim_OilRefinery_C.ExecuteUbergraph_Anim_OilRefinery
struct UAnim_OilRefinery_C_ExecuteUbergraph_Anim_OilRefinery_Params
{
	int                                                EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
