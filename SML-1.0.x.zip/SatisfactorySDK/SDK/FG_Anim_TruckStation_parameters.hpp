#pragma once

// Satisfactory SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "FG_Anim_TruckStation_classes.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Anim_TruckStation.Anim_TruckStation_C.CalculateAnimGraphVariables
struct UAnim_TruckStation_C_CalculateAnimGraphVariables_Params
{
};

// Function Anim_TruckStation.Anim_TruckStation_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_TruckStation_AnimGraphNode_TransitionResult_BA79A65D40E552FCF0E8F2AD451D5B6F
struct UAnim_TruckStation_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_TruckStation_AnimGraphNode_TransitionResult_BA79A65D40E552FCF0E8F2AD451D5B6F_Params
{
};

// Function Anim_TruckStation.Anim_TruckStation_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_TruckStation_AnimGraphNode_TransitionResult_B9266FD3469546EFB24EB0AAA526FD77
struct UAnim_TruckStation_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_TruckStation_AnimGraphNode_TransitionResult_B9266FD3469546EFB24EB0AAA526FD77_Params
{
};

// Function Anim_TruckStation.Anim_TruckStation_C.BlueprintUpdateAnimation
struct UAnim_TruckStation_C_BlueprintUpdateAnimation_Params
{
	float*                                             DeltaTimeX;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Anim_TruckStation.Anim_TruckStation_C.BlueprintInitializeAnimation
struct UAnim_TruckStation_C_BlueprintInitializeAnimation_Params
{
};

// Function Anim_TruckStation.Anim_TruckStation_C.HasPowerChanged
struct UAnim_TruckStation_C_HasPowerChanged_Params
{
	bool                                               State;                                                    // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Anim_TruckStation.Anim_TruckStation_C.ExecuteUbergraph_Anim_TruckStation
struct UAnim_TruckStation_C_ExecuteUbergraph_Anim_TruckStation_Params
{
	int                                                EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
