#pragma once

// Satisfactory SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "FG_Anim_MinerMk1_classes.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Anim_MinerMk1.Anim_MinerMk1_C.SetupReloadTimer
struct UAnim_MinerMk1_C_SetupReloadTimer_Params
{
};

// Function Anim_MinerMk1.Anim_MinerMk1_C.ReloadTimer
struct UAnim_MinerMk1_C_ReloadTimer_Params
{
};

// Function Anim_MinerMk1.Anim_MinerMk1_C.AnimNotify_MinerEnteredReloadState
struct UAnim_MinerMk1_C_AnimNotify_MinerEnteredReloadState_Params
{
};

// Function Anim_MinerMk1.Anim_MinerMk1_C.AnimNotify_StartDrillVFX
struct UAnim_MinerMk1_C_AnimNotify_StartDrillVFX_Params
{
};

// Function Anim_MinerMk1.Anim_MinerMk1_C.BlueprintInitializeAnimation
struct UAnim_MinerMk1_C_BlueprintInitializeAnimation_Params
{
};

// Function Anim_MinerMk1.Anim_MinerMk1_C.AnimNotify_OnResumeProducing
struct UAnim_MinerMk1_C_AnimNotify_OnResumeProducing_Params
{
};

// Function Anim_MinerMk1.Anim_MinerMk1_C.AnimNotify_OnStopProducing
struct UAnim_MinerMk1_C_AnimNotify_OnStopProducing_Params
{
};

// Function Anim_MinerMk1.Anim_MinerMk1_C.AnimNotify_StartEngineLoop
struct UAnim_MinerMk1_C_AnimNotify_StartEngineLoop_Params
{
};

// Function Anim_MinerMk1.Anim_MinerMk1_C.ExecuteUbergraph_Anim_MinerMk1
struct UAnim_MinerMk1_C_ExecuteUbergraph_Anim_MinerMk1_Params
{
	int                                                EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
