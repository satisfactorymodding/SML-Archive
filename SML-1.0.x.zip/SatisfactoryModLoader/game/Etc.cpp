#include <stdafx.h>
#include "Etc.h"

bool SML::Objects::AActor::Destroy(bool bNetForce, bool bShouldModifyLevel) { return false; }

void SML::Objects::AActor::BeginPlay() {}
