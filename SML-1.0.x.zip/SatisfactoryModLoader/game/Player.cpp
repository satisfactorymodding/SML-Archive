#include "stdafx.h"
#include "Player.h"

void SML::Objects::AFGCharacterPlayer::BeginPlay() {}