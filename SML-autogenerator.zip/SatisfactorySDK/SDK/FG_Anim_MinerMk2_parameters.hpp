#pragma once

// Satisfactory SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "FG_Anim_MinerMk2_classes.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Anim_MinerMk2.Anim_MinerMk2_C.SetupReloadTimer
struct UAnim_MinerMk2_C_SetupReloadTimer_Params
{
};

// Function Anim_MinerMk2.Anim_MinerMk2_C.ReloadTimer
struct UAnim_MinerMk2_C_ReloadTimer_Params
{
};

// Function Anim_MinerMk2.Anim_MinerMk2_C.AnimNotify_MinerEnteredReloadState
struct UAnim_MinerMk2_C_AnimNotify_MinerEnteredReloadState_Params
{
};

// Function Anim_MinerMk2.Anim_MinerMk2_C.AnimNotify_StartDrillVFX
struct UAnim_MinerMk2_C_AnimNotify_StartDrillVFX_Params
{
};

// Function Anim_MinerMk2.Anim_MinerMk2_C.BlueprintInitializeAnimation
struct UAnim_MinerMk2_C_BlueprintInitializeAnimation_Params
{
};

// Function Anim_MinerMk2.Anim_MinerMk2_C.AnimNotify_OnResumeProducing
struct UAnim_MinerMk2_C_AnimNotify_OnResumeProducing_Params
{
};

// Function Anim_MinerMk2.Anim_MinerMk2_C.AnimNotify_OnStopProducing
struct UAnim_MinerMk2_C_AnimNotify_OnStopProducing_Params
{
};

// Function Anim_MinerMk2.Anim_MinerMk2_C.AnimNotify_StartEngineLoop
struct UAnim_MinerMk2_C_AnimNotify_StartEngineLoop_Params
{
};

// Function Anim_MinerMk2.Anim_MinerMk2_C.ExecuteUbergraph_Anim_MinerMk2
struct UAnim_MinerMk2_C_ExecuteUbergraph_Anim_MinerMk2_Params
{
	int                                                EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
