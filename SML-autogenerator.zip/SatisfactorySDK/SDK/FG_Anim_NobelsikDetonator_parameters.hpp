#pragma once

// Satisfactory SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "FG_Anim_NobelsikDetonator_classes.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Anim_NobelsikDetonator.Anim_NobelsikDetonator_C.AnimNotify_NobeliskDetonate
struct UAnim_NobelsikDetonator_C_AnimNotify_NobeliskDetonate_Params
{
};

// Function Anim_NobelsikDetonator.Anim_NobelsikDetonator_C.AnimNotify_NobeliskThrowRelease
struct UAnim_NobelsikDetonator_C_AnimNotify_NobeliskThrowRelease_Params
{
};

// Function Anim_NobelsikDetonator.Anim_NobelsikDetonator_C.ExecuteUbergraph_Anim_NobelsikDetonator
struct UAnim_NobelsikDetonator_C_ExecuteUbergraph_Anim_NobelsikDetonator_Params
{
	int                                                EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
