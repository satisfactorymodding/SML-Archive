#pragma once

// Satisfactory SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "FG_Basic.hpp"
#include "FG_PhysXVehicles_classes.hpp"
#include "FG_AnimGraphRuntime_classes.hpp"
#include "FG_Engine_classes.hpp"
#include "FG_CoreUObject_classes.hpp"

namespace SDK
{
}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
