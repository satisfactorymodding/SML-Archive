// Satisfactory SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "FG_Anim_LandingPad_parameters.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function Anim_LandingPad.Anim_LandingPad_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_LandingPad_AnimGraphNode_TransitionResult_1EB610874256993492C21CB7314D49F1
// ()

void UAnim_LandingPad_C::EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_LandingPad_AnimGraphNode_TransitionResult_1EB610874256993492C21CB7314D49F1()
{
	static auto fn = UObject::FindObject<UFunction>("Function Anim_LandingPad.Anim_LandingPad_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_LandingPad_AnimGraphNode_TransitionResult_1EB610874256993492C21CB7314D49F1");

	UAnim_LandingPad_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_LandingPad_AnimGraphNode_TransitionResult_1EB610874256993492C21CB7314D49F1_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function Anim_LandingPad.Anim_LandingPad_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_LandingPad_AnimGraphNode_TransitionResult_E4A0A1484FD618C09AC43E9C16D4A37B
// ()

void UAnim_LandingPad_C::EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_LandingPad_AnimGraphNode_TransitionResult_E4A0A1484FD618C09AC43E9C16D4A37B()
{
	static auto fn = UObject::FindObject<UFunction>("Function Anim_LandingPad.Anim_LandingPad_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_LandingPad_AnimGraphNode_TransitionResult_E4A0A1484FD618C09AC43E9C16D4A37B");

	UAnim_LandingPad_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Anim_LandingPad_AnimGraphNode_TransitionResult_E4A0A1484FD618C09AC43E9C16D4A37B_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function Anim_LandingPad.Anim_LandingPad_C.HasPowerChanged
// ()
// Parameters:
// bool                           State                          (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)

void UAnim_LandingPad_C::HasPowerChanged(bool State)
{
	static auto fn = UObject::FindObject<UFunction>("Function Anim_LandingPad.Anim_LandingPad_C.HasPowerChanged");

	UAnim_LandingPad_C_HasPowerChanged_Params params;
	params.State = State;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function Anim_LandingPad.Anim_LandingPad_C.BlueprintInitializeAnimation
// ()

void UAnim_LandingPad_C::BlueprintInitializeAnimation()
{
	static auto fn = UObject::FindObject<UFunction>("Function Anim_LandingPad.Anim_LandingPad_C.BlueprintInitializeAnimation");

	UAnim_LandingPad_C_BlueprintInitializeAnimation_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function Anim_LandingPad.Anim_LandingPad_C.ExecuteUbergraph_Anim_LandingPad
// ()
// Parameters:
// int                            EntryPoint                     (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)

void UAnim_LandingPad_C::ExecuteUbergraph_Anim_LandingPad(int EntryPoint)
{
	static auto fn = UObject::FindObject<UFunction>("Function Anim_LandingPad.Anim_LandingPad_C.ExecuteUbergraph_Anim_LandingPad");

	UAnim_LandingPad_C_ExecuteUbergraph_Anim_LandingPad_Params params;
	params.EntryPoint = EntryPoint;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
