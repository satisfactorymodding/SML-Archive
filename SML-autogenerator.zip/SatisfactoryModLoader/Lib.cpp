#include <stdafx.h>
#include <string>
#include <vector>
